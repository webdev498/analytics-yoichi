const staticLayout = {
  'layout': [
    /*[
      {
        'id': '1',
        'type': 'MetricsCard',
        'meta': {
          'showHeader': false,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_alert_count_time_shifted'
            }
          }
        },
        'name': 'MetricsCard',
        'attributes': {
          'style': {
            'borderTop': '6px solid #F69275',
            'width': '25%',
            'marginRight': '3px'
          },
          'countStyle': {
            'color': '#F69275'
          },
          'title': 'High Priority Alerts'
        },
        'kibana': {
          'pathParams': [
            'alerts-score'
          ],
          'queryParams': {
            'fromAndToBasedOnToday': '',
            'scoreRange': ''
          }
        }
      },
      {
        'id': '2',
        'type': 'MetricsCard',
        'meta': {
          'showHeader': false,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_malware_count_time_shifted'
            }
          }
        },
        'name': 'MetricsCard',
        'attributes': {
          'style': {
            'borderTop': '6px solid #F69275',
            'width': '25%',
            'marginRight': '3px'
          },
          'countStyle': {
            'color': '#F69275'
          },
          'title': 'High Priority Malware'
        }
      },
      {
        'id': '3',
        'type': 'MetricsCard',
        'meta': {
          'showHeader': false,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_event_count_time_shifted'
            }
          }
        },
        'name': 'MetricsCard',
        'attributes': {
          'style': {
            'borderTop': '6px solid #2bd8d0',
            'width': '25%',
            'marginRight': '3px'
          },
          'countStyle': {
            'color': '#2bd8d0'
          },
          'title': 'Events Processed'
        },
        'kibana': {
          'pathParams': [
            'traffic-details'
          ],
          'queryParams': {
            'fromAndToBasedOnToday': ''
          }
        }
      },
      {
        'id': '4',
        'type': 'MetricsCard',
        'meta': {
          'showHeader': false,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_asset_count_time_shifted'
            }
          }
        },
        'name': 'MetricsCard',
        'attributes': {
          'style': {
            'borderTop': '6px solid #2bd8d0',
            'width': '25%',
            'marginRight': '3px'
          },
          'countStyle': {
            'color': '#2bd8d0'
          },
          'title': 'Assets Monitored'
        },
        'kibana': {
          'pathParams': [
            'assets-all'
          ],
          'queryParams': {
            'fromAndToBasedOnToday': ''
          }
        }
      }
    ],*/
    /*[
      {
        'id': 'RecentAlerts',
        'type': 'Table',
        'name': 'Table',
        'meta': {
          'showHeader': true,
          'showSearch': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '',
              'count': 200
            },
            'pathParams': {
              'reportId': 'taf_alert_highpriority'
            }
          },
          'title': 'Recent Alerts'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'RecentAlerts'
        },
        'tableData': {
          'fieldMapping': [
            {
              'reportId': 'taf_alert_highpriority',
              'columns': [
                {
                  'type': 'scoreWidget',
                  'columnNameToDisplay': 'RANK SCORE',
                  'data': [
                    {
                      'fieldName': 'data.rank_alert.score'
                    }
                  ],
                  'style': {
                    'width': '12%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DATE',
                  'data': [
                    {
                      'fieldName': 'date',
                      'displayName': 'date'
                    }
                  ],
                  'style': {
                    'width': '10%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DETAILS',
                  'data': [
                    {
                      'fieldName': 'data.rank_alert.description',
                      'displayName': 'description'
                    },
                    {
                      'fieldName': 'data.rank_alert.message',
                      'displayName': ''
                    }
                  ],
                  'style': {
                    'width': '38%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'SOURCE',
                  'data': [
                    {
                      'fieldName': 'source.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'source.port',
                      'displayName': 'port'
                    },
                    {
                      'fieldName': 'source.country',
                      'displayName': 'countryFlag'
                    },
                    {
                      'fieldName': 'source.additionalInfo.user',
                      'displayName': 'User'
                    },
                    {
                      'fieldName': 'source.additionalInfo.machine',
                      'displayName': 'Machine'
                    }
                  ],
                  'style': {
                    'width': '20%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DESTINATION',
                  'data': [
                    {
                      'fieldName': 'destination.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'destination.port',
                      'displayName': 'port'
                    },
                    {
                      'fieldName': 'destination.country',
                      'displayName': 'countryFlag'
                    },
                    {
                      'fieldName': 'destination.additionalInfo.user',
                      'displayName': 'User'
                    },
                    {
                      'fieldName': 'destination.additionalInfo.machine',
                      'displayName': 'Machine'
                    }
                  ],
                  'style': {
                    'width': '20%'
                  }
                }
              ]
            }
          ]
        },
        'tableOptions': {
          'sortable': [
            'RANK SCORE',
            'DATE',
            'DETAILS',
            'SOURCE',
            'DESTINATION'
          ],
          'defaultSort': {
            'column': 'RANK SCORE',
            'direction': 'desc'
          },
          'filterable': [
            'DATE',
            'DETAILS',
            'SOURCE',
            'DESTINATION'
          ],
          'itemsPerPage':5
        }
      }
    ],*/
    /*[
      {
        'id': 'AlertByType',
        'type': 'ParetoChart',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_threat_trend'
            }
          },
          'title': 'Alert by type'
        },
        'attributes': {
          'style': {
            'width': '50%',
            'marginRight': '33px'
          },
          'id': 'AlertByType',
          'chartWidth': '100%',
          'chartHeight': '350'
        },
        'chartOptions': {
          'pYAxisname': 'CONNECTIONS',
          'xAxisname': 'ALERT TYPES',
          'baseFont': 'Open Sans, sans-serif',
          'baseFontColor': '#6B7282'
        },
        'chartData': {
          'fieldMapping': [
            {
              'axis': 'x',
              'reportId': 'taf_threat_trend',
              'columns': [
                'data.rank_alert.category'
              ]
            },
            {
              'axis': 'y',
              'reportId': 'taf_threat_trend',
              'columns': [
                'date'
              ]
            }
          ]
        },
        'kibana': {
          'pathParams': [
            'alerts-type'
          ],
          'queryParams': {
            'type': '',
            'window': ''
          }
        }
      },
      {
        'id': 'AlertPriorityChart',
        'type': 'MultiSeriesCombiChart',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_alert_priority_time'
            }
          },
          'title': 'Alert priority'
        },
        'attributes': {
          'style': {
            'width': '50%'
          },
          'id': 'AlertPriorityChart',
          'chartWidth': '100%',
          'chartHeight': '350',
          'chartCaption': {
            'display': 'none'
          }
        },
        'chartOptions': {
          'yAxisName': 'ALERT COUNT',
          'drawAnchors': '1',
          'legendPosition': 'right',
          'linealpha': '0',
          'paletteColors': '#2BD8D0, #6CD3B4, #B6CD94, #FCC875, #05E9F5',
          'baseFont': 'Open Sans, sans-serif',
          'baseFontColor': '#6B7282'
        },
        'chartData': {
          'combinedResult': false,
          'fieldMapping': [
            {
              'axis': 'x',
              'reportId': 'taf_alert_priority_time',
              'columns': [
                'date'
              ]
            },
            {
              'axis': 'y',
              'seriesOptions': {
                'renderas': 'Line',
                'lineThickness': '0',
                'drawanchors': '1',
                'anchorradius': '5',
                'anchorsides': [
                  '0',
                  '0',
                  '0'
                ],
                'anchorBorderColor': [
                  '#90d0a4',
                  '#fcc875',
                  '#ef5976'
                ],
                'anchorbgcolor': [
                  '#90d0a4',
                  '#fcc875',
                  '#ef5976'
                ]
              },
              'reportId': 'taf_alert_priority_time',
              'columns': [
                'data.rank_alert.score',
                'count'
              ]
            }
          ]
        },
        'kibana': {
          'pathParams': [
            'alerts-score'
          ],
          'queryParams': {
            'scoreRange': '',
            'fromAndToBasedOnClickedDate': ''
          }
        }
      }
    ],*/
    [
      {
        'id': 'OutgoingTrafficHeatMap',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'title': 'Outgoing Traffic HeatMap'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'OutgoingTrafficHeatMap'
        },
        'children': [
          {
            'type': 'WorldMap',
            'parent': 'compound',
            'meta': {
              'showHeader': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_dest_countries,taf_dest_bad_reputation_countries'
                }
              },
              'title': 'Outgoing Traffic Heatmap',
              'subTitle': 'NUMBER OF OUTGOING CONNECTIONS BY COUNTRY'
            },
            'attributes': {
              'style': {
                'width': '70%',
                'marginRight': '33px'
              },
              'id': 'OutgoingTrafficWorldMap',
              'chartWidth': '100%',
              'chartHeight': '600'
            },
            'chartOptions': {
              'chartTopMargin': '0',
              'chartLeftMargin': '0',
              'chartRightMargin': '0',
              'chartBottomMargin': '0'
            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_dest_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'secure'
                },
                {
                  'reportId': 'taf_dest_bad_reputation_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'malicious'
                }
              ]
            },
            'kibana': {
              'pathParams': [
                'destination-country-details'
              ],
              'queryParams': {
                'country': '',
                'fromAndToBasedOnToday': ''
              }
            }
          },
          {
            'id': 'OutgoingTrafficHeatMapLegends',
            'type': 'Compound',
            'name': 'Compound',
            'meta': {
              'showHeader': false,
              'parentWrap': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_dest_countries,taf_dest_bad_reputation_countries'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '30%',
                'flexWrap': 'wrap',
                'flexDirection': 'column'
              },
              'id': 'OutgoingTrafficHeatMapLegends'
            },
            'children': [
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'Top 5 Connections'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'OutgoingTopCountries',
                  'chartBorder': {
                  },
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_dest_countries',
                      'columns': [
                        'country_name',
                        'connections'
                      ]
                    }
                  ]
                }
              },
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'TOP 5 BANDWIDTH'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'OutgoingTopBandwidth',
                  'chartBorder': {
                  },
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_dest_countries',
                      'columns': [
                        'country_name',
                        'bandwidth'
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ],
    [
      {
        'id': 'IncomingTrafficHeatMap',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'title': 'Incoming Traffic HeatMap'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'IncomingTrafficHeatMap'
        },
        'children': [
          {
            'type': 'WorldMap',
            'parent': 'compound',
            'meta': {
              'showHeader': false,
              'title': 'Incoming Traffic Heatmap',
              'subTitle': 'NUMBER OF INCOMING CONNECTIONS BY COUNTRY',
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_source_countries,taf_source_bad_reputation_countries'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '70%',
                'marginRight': '33px'
              },
              'id': 'IncomingTrafficWorldMap',
              'chartWidth': '100%',
              'chartHeight': '600'
            },
            'chartOptions': {

            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_source_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'secure'
                },
                {
                  'reportId': 'taf_source_bad_reputation_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'malicious'
                }
              ]
            },
            'kibana': {
              'pathParams': [
                'source-country-details'
              ],
              'queryParams': {
                'country': '',
                'fromAndToBasedOnToday': ''
              }
            }
          },
          {
            'id': 'IncomingTrafficHeatMapLegends',
            'type': 'Compound',
            'name': 'Compound',
            'meta': {
              'showHeader': false,
              'parentWrap': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_source_countries,taf_source_bad_reputation_countries'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '30%',
                'flexWrap': 'wrap',
                'flexDirection': 'column'
              },
              'id': 'IncomingTrafficHeatMapLegends'
            },
            'children': [
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'TOP 5 CONNECTIONS'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'IncomingTopCountries',
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_source_countries',
                      'columns': [
                        'country_name',
                        'connections'
                      ]
                    }
                  ]
                }
              },
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'TOP 5 BANDWIDTH'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'IncomingTopBandwidth',
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_source_countries',
                      'columns': [
                        'country_name',
                        'bandwidth'
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ]//,
    /*OLD[
      {
        'id': 'OutgoingTrafficHeatMap',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '1d'
            },
            'pathParams': {
              'reportId': 'taf_dest_countries,taf_dest_bad_reputation_countries'
            }
          },
          'title': 'Outgoing Traffic HeatMap'
        },
        'attributes': {
          'style': {
            'width': '100%',
            'marginRight': '33px'
          },
          'id': 'OutgoingTrafficHeatMap'
        },
        'children': [
          {
            'type': 'WorldMap',
            'parent': 'compound',
            'meta': {
              'showHeader': false,
              'title': 'Outgoing Traffic Heatmap',
              'subTitle': 'NUMBER OF OUTGOING CONNECTIONS BY COUNTRY'
            },
            'attributes': {
              'style': {
                'width': '70%',
                'marginRight': '33px'
              },
              'id': 'OutgoingTrafficWorldMap',
              'chartWidth': '100%',
              'chartHeight': '600'
            },
            'chartOptions': {
              'chartTopMargin': '0',
              'chartLeftMargin': '0',
              'chartRightMargin': '0',
              'chartBottomMargin': '0'
            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_dest_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'secure'
                },
                {
                  'reportId': 'taf_dest_bad_reputation_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'malicious'
                }
              ]
            },
            'kibana': {
              'pathParams': [
                'destination-country-details'
              ],
              'queryParams': {
                'country': '',
                'fromAndToBasedOnToday': ''
              }
            }
          },
          {
            'id': 'OutgoingTrafficHeatMapLegends',
            'type': 'Compound',
            'name': 'Compound',
            'meta': {
              'showHeader': false,
              'parentWrap': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_dest_countries,taf_dest_bad_reputation_countries'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '30%',
                'flexWrap': 'wrap',
                'flexDirection': 'column'
              },
              'id': 'OutgoingTrafficHeatMapLegends'
            },
            'children': [
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'Top 5 Connections'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'OutgoingTopCountries',
                  'chartBorder': {
                    'width': '20%'
                  },
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_dest_countries',
                      'columns': [
                        'country_name',
                        'connections'
                      ]
                    }
                  ]
                }
              },
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'TOP 5 BANDWIDTH'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'OutgoingTopBandwidth',
                  'chartBorder': {
                    'width': '20%'
                  },
                  'chartCaption': {
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'color': '#6b7282',
                    'fontWeight': '600'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_dest_countries',
                      'columns': [
                        'country_name',
                        'bandwidth'
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ],
    [
      {
        'id': 'IncomingTrafficHeatMap',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '1d'
            },
            'pathParams': {
              'reportId': 'taf_source_countries,taf_source_bad_reputation_countries'
            }
          },
          'title': 'Incoming Traffic HeatMap'
        },
        'attributes': {
          'style': {
            'width': '100%',
            'marginRight': '33px'
          },
          'id': 'IncomingTrafficHeatMap'
        },
        'children': [
          {
            'type': 'WorldMap',
            'parent': 'compound',
            'meta': {
              'showHeader': false,
              'title': 'Incoming Traffic Heatmap',
              'subTitle': 'NUMBER OF INCOMING CONNECTIONS BY COUNTRY'
            },
            'attributes': {
              'style': {
                'width': '70%',
                'marginRight': '33px'
              },
              'id': 'IncomingTrafficWorldMap',
              'chartWidth': '100%',
              'chartHeight': '600'
            },
            'chartOptions': {

            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_source_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'secure'
                },
                {
                  'reportId': 'taf_source_bad_reputation_countries',
                  'columns': [
                    'source.country',
                    'pos_x',
                    'pos_y',
                    'connections'
                  ],
                  'connection': 'malicious'
                }
              ]
            },
            'kibana': {
              'pathParams': [
                'source-country-details'
              ],
              'queryParams': {
                'country': '',
                'fromAndToBasedOnToday': ''
              }
            }
          },
          {
            'id': 'IncomingTrafficHeatMapLegends',
            'type': 'Compound',
            'name': 'Compound',
            'meta': {
              'showHeader': false,
              'parentWrap': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_source_countries,taf_source_bad_reputation_countries'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '30%',
                'flexWrap': 'wrap',
                'flexDirection': 'column'
              },
              'id': 'IncomingTrafficHeatMapLegends'
            },
            'children': [
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'Top 5 Connections'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'IncomingTopCountries',
                  'chartBorder': {
                    'border': '3px solid #BBBABA',
                    'float': 'left',
                    'width': '48%',
                    'margin': '1%'
                  },
                  'chartCaption': {
                    'width': '100%',
                    'color': '#555555',
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'fontWeight': 'bold',
                    'textAlign': 'center',
                    'paddingTop': '10px'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_source_countries',
                      'columns': [
                        'country_name',
                        'connections'
                      ]
                    }
                  ]
                }
              },
              {
                'type': 'HorizontalBarChart',
                'parent': 'Compound',
                'meta': {
                  'showHeader': false,
                  'title': 'Top 5 Bandwidth'
                },
                'attributes': {
                  'style': {
                  },
                  'id': 'IncomingTopBandwidth',
                  'chartBorder': {
                    'border': '3px solid #BBBABA',
                    'float': 'left',
                    'width': '48%',
                    'margin': '1%'
                  },
                  'chartCaption': {
                    'width': '100%',
                    'color': '#555555',
                    'fontFamily': 'Open Sans, sans-serif',
                    'fontSize': '14px',
                    'fontWeight': 'bold',
                    'textAlign': 'center',
                    'paddingTop': '10px'
                  },
                  'chartWidth': '100%',
                  'chartHeight': '200'
                },
                'chartOptions': {
                  'baseFont': 'Open Sans, sans-serif',
                  'baseFontColor': '#6B7282'
                },
                'chartData': {
                  'multipleReportIds': false,
                  'displayTopFive': true,
                  'showTrendLines': false,
                  'fieldMapping': [
                    {
                      'reportId': 'taf_source_countries',
                      'columns': [
                        'country_name',
                        'bandwidth'
                      ]
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ],*/
    /*[
      {
        'id': 'TrafficDetails',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '1d'
            },
            'pathParams': {
              'reportId': 'taf_stats_histogram,taf_connections_by_protocol'
            }
          },
          'title': 'Traffic Details'
        },
        'attributes': {
          'style': {
            'width': '100%',
            'marginRight': '33px'
          },
          'id': 'TrafficDetails'
        },
        'children': [
          {
            'type': 'MultiSeriesCombiChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'Incoming Bandwidth'
            },
            'attributes': {
              'style': {
                'width': '48%'
              },
              'id': 'HistogramChart1',
              'chartBorder': {
                'border': '3px solid #BBBABA',
                'float': 'left',
                'width': '48%',
                'margin': '1%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#555555',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'textAlign': 'center',
                'paddingTop': '10px'
              }
            },
            'chartOptions': {
              'xAxisName': 'Time',
              'yAxisName': 'Incoming Bandwidth',
              'lineThickness': '5',
              'paletteColors': '#d3d3d3, #D93609, #0505F5, #ACF50F,#FCFC0D, #05E9F5',
              'drawAnchors': '0',
              'usePlotGradientColor': '1',
              'plotGradientColor': '#887788'
            },
            'chartData': {
              'combinedResult': true,
              'fieldMapping': [
                {
                  'axis': 'x',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'date'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Historical Incoming Bandwidth',
                  'renderas': 'Area',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'bytes_in[1]'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Current Incoming Bandwidth',
                  'renderas': 'Line',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'bytes_in[0]'
                  ]
                }
              ]
            }
          },
          {
            'type': 'MultiSeriesCombiChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'Outgoing Bandwidth'
            },
            'attributes': {
              'style': {
                'width': '48%'
              },
              'id': 'HistogramChart2',
              'chartBorder': {
                'border': '3px solid #BBBABA',
                'float': 'left',
                'width': '48%',
                'margin': '1%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#555555',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'textAlign': 'center',
                'paddingTop': '10px'
              }
            },
            'chartOptions': {
              'xAxisName': 'Time',
              'yAxisName': 'Outgoing Bandwidth',
              'lineThickness': '5',
              'paletteColors': '#d3d3d3, #D93609, #0505F5, #ACF50F,#FCFC0D, #05E9F5',
              'drawAnchors': '0',
              'usePlotGradientColor': '1',
              'plotGradientColor': '#887788'
            },
            'chartData': {
              'combinedResult': true,
              'fieldMapping': [
                {
                  'axis': 'x',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'date'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Historical Outgoing Bandwidth',
                  'renderas': 'Area',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'bytes_out[1]'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Current Outgoing Bandwidth',
                  'renderas': 'Line',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'bytes_out[0]'
                  ]
                }
              ]
            }
          },
          {
            'type': 'MultiSeriesCombiChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'No. of Connections'
            },
            'attributes': {
              'style': {
                'width': '48%'
              },
              'id': 'HistogramChart3',
              'chartBorder': {
                'border': '3px solid #BBBABA',
                'float': 'left',
                'width': '48%',
                'margin': '1%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#555555',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'textAlign': 'center',
                'paddingTop': '10px'
              }
            },
            'chartOptions': {
              'xAxisName': 'Time',
              'yAxisName': 'No. of Connections',
              'lineThickness': '5',
              'paletteColors': '#d3d3d3, #D93609, #0505F5, #ACF50F,#FCFC0D, #05E9F5',
              'drawAnchors': '0',
              'usePlotGradientColor': '1',
              'plotGradientColor': '#887788'
            },
            'chartData': {
              'combinedResult': true,
              'fieldMapping': [
                {
                  'axis': 'x',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'date'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Historical Connections',
                  'renderas': 'Area',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'conn[1]'
                  ]
                },
                {
                  'axis': 'y',
                  'seriesname': 'Current Connections',
                  'renderas': 'Line',
                  'reportId': 'taf_stats_histogram',
                  'columns': [
                    'conn[0]'
                  ]
                }
              ]
            }
          },
          {
            'type': 'HorizontalBarChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'Top Connections By Protocol'
            },
            'attributes': {
              'style': {
                'width': '48%',
                'marginRight': '33px'
              },
              'id': 'TopConnectionsByProtocol',
              'chartBorder': {
                'border': '3px solid #BBBABA',
                'float': 'left',
                'width': '48%',
                'margin': '1%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#555555',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'textAlign': 'center',
                'paddingTop': '10px'
              }
            },
            'chartOptions': {
              'baseFont': 'Open Sans, sans-serif',
              'baseFontColor': '#6B7282'
            },
            'chartData': {
              'multipleReportIds': false,
              'showTrendLines': false,
              'fieldMapping': [
                {
                  'reportId': 'taf_connections_by_protocol',
                  'columns': [
                    'protocol.service',
                    'date'
                  ]
                }
              ]
            }
          }
        ]
      }
    ],
    [
      {
        'id': 'LongestConnections',
        'type': 'Table',
        'name': 'Table',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': ''
            },
            'pathParams': {
              'reportId': 'taf_top_longest_connections'
            }
          },
          'title': 'Longest Connections'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'LongestConnections'
        },
        'tableData': {
          'fieldMapping': [
            {
              'reportId': 'taf_top_longest_connections',
              'columns': [
                {
                  'type': 'text',
                  'columnNameToDisplay': 'END DATE',
                  'data': [
                    {
                      'fieldName': 'date',
                      'displayName': 'date'
                    }
                  ],
                  'style': {
                    'width': '12%'
                  }
                },
                {
                  'type': 'durationWidget',
                  'columnNameToDisplay': 'DURATION',
                  'data': [
                    {
                      'fieldName': 'data.conn.duration',
                      'displayName': 'duration'
                    }
                  ],
                  'style': {
                    'width': '15%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DETAILS',
                  'data': [
                    {
                      'fieldName': 'protocol.service',
                      'displayName': 'description'
                    },
                    {
                      'fieldName': 'data.conn.reqBytes',
                      'displayName': 'Incoming bytes'
                    },
                    {
                      'fieldName': 'data.conn.respBytes',
                      'displayName': 'Outcoming bytes'
                    }
                  ],
                  'style': {
                    'width': '30%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'SOURCE',
                  'data': [
                    {
                      'fieldName': 'source.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'source.port',
                      'displayName': 'port'
                    },
                    {
                      'fieldName': 'source.country',
                      'displayName': 'countryFlag'
                    },
                    {
                      'fieldName': 'source.additionalInfo.user',
                      'displayName': 'User'
                    },
                    {
                      'fieldName': 'source.additionalInfo.machine',
                      'displayName': 'Machine'
                    },
                    {
                      'fieldName': 'source.owner',
                      'displayName': 'Owner'
                    },
                    {
                      'fieldName': 'source.asn',
                      'displayName': 'ASN'
                    }
                  ],
                  'style': {
                    'width': '20%'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DESTINATION',
                  'data': [
                    {
                      'fieldName': 'destination.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'destination.port',
                      'displayName': 'port'
                    },
                    {
                      'fieldName': 'destination.country',
                      'displayName': 'countryFlag'
                    },
                    {
                      'fieldName': 'destination.additionalInfo.user',
                      'displayName': 'User'
                    },
                    {
                      'fieldName': 'destination.additionalInfo.machine',
                      'displayName': 'Machine'
                    },
                    {
                      'fieldName': 'destination.owner',
                      'displayName': 'Owner'
                    },
                    {
                      'fieldName': 'destination.asn',
                      'displayName': 'ASN'
                    }
                  ],
                  'style': {
                    'width': '20%'
                  }
                }
              ]
            }
          ]
        },
        'tableOptions': {
          'sortable': [
            'END DATE',
            'DURATION',
            'DETAILS',
            'SOURCE',
            'DESTINATION'
          ],
          'defaultSort': {
            'column': 'DURATION',
            'direction': 'asc'
          },
          'filterable': [],
          'itemsPerPage':5
        },
        'kibana': {
          'pathParams': [
            'connection-details'
          ],
          'queryParams': {
            'correlationIds': 'correlationIds[0]'
          }
        }
      }
    ],*/
    /*[
      {
        'id': 'AssetDetailsConnections',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'title': 'Connections'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'AssetDetailsConnections'
        },
        'children': [
          {
            'type': 'PieChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'TOP CONNECTIONS',
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d',
                  'timeShift': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted'
                }
              },
              'legend': [
                'Connections',
                'Used by',
                'Assets'
              ]
            },
            'attributes': {
              'style': {
                'width': '100%',
                'marginRight': '33px'
              },
              'id': 'PieChartConnections',
              'chartBorder': {
                'marginTop': '-30px',
                'marginRight': '30px',
                'width': '48%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#444C63',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'paddingTop': '30px',
                'paddingBottom': '30px',
                'paddingLeft': '20px',
                'backgroundColor': 'lightgray'
              }
            },
            'chartOptions': {
              'highlightedColor1': '#2BD8D0',
              'nonHighlightedColor': '#E5E5EA'
            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_asset_count_time_shifted',
                  'columns': [
                    '0.0'
                  ]
                },
                {
                  'reportId': 'taf_total_usage',
                  'columns': [
                    'date'
                  ]
                },
                {
                  'reportId': 'taf_top_talkers_connections',
                  'columns': [
                    'connections'
                  ]
                }
              ]
            }
          },
          {
            'type': 'HorizontalBarChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'TOP IPS USING THE MOST CONNECTIONS',
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'queryParams': {
                  'window': '1d',
                  'timeShift': '1d'
                },
                'pathParams': {
                  'reportId': 'taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted'
                }
              }
            },
            'attributes': {
              'style': {
                'width': '48%',
                'marginRight': '33px'
              },
              'id': 'HorizontalBarChartConnections',
              'id1': 'HorizontalBarChartConnections1',
              'chartBorder': {
                'marginTop': '-30px',
                'width': '48%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#444C63',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'paddingTop': '30px',
                'paddingBottom': '30px',
                'paddingLeft': '20px',
                'backgroundColor': 'lightgray'
              }
            },
            'chartOptions': {
              'numberSuffix': '%',
              'baseFont': 'Open Sans, sans-serif',
              'baseFontColor': '#6B7282'
            },
            'chartData': {
              'multipleReportIds': true,
              'showTrendLines': true,
              'trendLines': [
                {
                  'line': [
                    {
                      'color': '#1aaf5d',
                      'valueOnRight': '1',
                      'dashed': '1',
                      'dashLen': '4',
                      'dashGap': '2'
                    }
                  ]
                }
              ],
              'reportId': 'taf_top_talkers_connections',
              'fieldMapping': [
                {
                  'reportId': 'taf_asset_count_time_shifted',
                  'columns': [
                    '0.0'
                  ]
                },
                {
                  'reportId': 'taf_total_usage',
                  'columns': [
                    'date'
                  ]
                },
                {
                  'reportId': 'taf_top_talkers_connections',
                  'columns': [
                    'connections'
                  ]
                }
              ]
            }
          }
        ]
      }
    ],
    [
      {
        'id': 'AssetDetailsBandwidth',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '1d',
              'timeShift': '1d'
            },
            'pathParams': {
              'reportId': 'taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted'
            }
          },
          'title': 'Bandwidth'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'AssetDetailsBandwidth'
        },
        'children': [
          {
            'type': 'PieChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'TOP BANDWIDTH',
              'legend': [
                'Bandwidth ',
                'Used by',
                'Assets'
              ]
            },
            'attributes': {
              'style': {
                'width': '50%',
                'marginRight': '33px'
              },
              'id': 'PieChartBandwidth',
              'chartBorder': {
                'marginTop': '-30px',
                'marginRight': '30px',
                'width': '48%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#444C63',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'paddingTop': '30px',
                'paddingBottom': '30px',
                'paddingLeft': '20px',
                'backgroundColor': 'lightgray'
              }
            },
            'chartOptions': {
              'highlightedColor1': '#2BD8D0',
              'nonHighlightedColor': '#E5E5EA'
            },
            'chartData': {
              'fieldMapping': [
                {
                  'reportId': 'taf_asset_count_time_shifted',
                  'columns': [
                    '0.0'
                  ]
                },
                {
                  'reportId': 'taf_total_usage',
                  'columns': [
                    'bandwidth'
                  ]
                },
                {
                  'reportId': 'taf_top_talkers_bandwidth',
                  'columns': [
                    'bandwidth'
                  ]
                }
              ]
            }
          },
          {
            'type': 'HorizontalBarChart',
            'parent': 'Compound',
            'meta': {
              'showHeader': false,
              'title': 'TOP IPS USING THE HIGHEST BANDWIDTH'
            },
            'attributes': {
              'style': {
                'width': '48%',
                'marginRight': '33px'
              },
              'id': 'HorizontalBarChartBandwidth',
              'id1': 'HorizontalBarChartBandwidth1',
              'chartBorder': {
                'marginTop': '-30px',
                'width': '48%'
              },
              'chartCaption': {
                'width': '100%',
                'color': '#444C63',
                'fontFamily': 'Open Sans, sans-serif',
                'fontSize': '14px',
                'fontWeight': 'bold',
                'paddingTop': '30px',
                'paddingBottom': '30px',
                'paddingLeft': '20px',
                'backgroundColor': 'lightgray'
              }
            },
            'chartOptions': {
              'numberSuffix': '%',
              'baseFont': 'Open Sans, sans-serif',
              'baseFontColor': '#6B7282'
            },
            'chartData': {
              'multipleReportIds': true,
              'showTrendLines': true,
              'trendLines': [
                {
                  'line': [
                    {
                      'color': '#1aaf5d',
                      'valueOnRight': '1',
                      'dashed': '1',
                      'dashLen': '4',
                      'dashGap': '2'
                    }
                  ]
                }
              ],
              'reportId': 'taf_top_talkers_bandwidth',
              'fieldMapping': [
                {
                  'reportId': 'taf_asset_count_time_shifted',
                  'columns': [
                    '0.0'
                  ]
                },
                {
                  'reportId': 'taf_total_usage',
                  'columns': [
                    'bandwidth'
                  ]
                },
                {
                  'reportId': 'taf_top_talkers_bandwidth',
                  'columns': [
                    'bandwidth'
                  ]
                }
              ]
            }
          }
        ]
      }
    ]*///,
    /*[
      {
        'id': 'UserAgentLength',
        'type': 'ScatterChart',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'queryParams': {
              'window': '1d'
            },
            'pathParams': {
              'reportId': 'taf_user_agent_unique'
            }
          },
          'title': 'User Agent Details'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'UserAgentLength',
          'chartWidth': '100%',
          'chartHeight': '200'
        },
        'chartOptions': {
          'xAxisName': 'User Agent Length',
          'yAxisName': 'Connection Count'
        },
        'chartData': {
          'fieldMapping': [
            {
              'seriesname': 'User Agent Length',
              'drawline': '0',
              'anchorsides': '3',
              'anchorradius': '10',
              'color': '#0505F5',
              'anchorbgcolor': '#9F9FF5',
              'anchorbordercolor': '#0505F5',
              'reportId': 'taf_user_agent_unique',
              'columns': [
                'data.http.__info.userAgentLen',
                'date'
              ]
            }
          ]
        }
      }
    ],
    [
      {
        'id': 'UserAgentDetails',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/reporting/execute/{reportId}',
            'headers': {
              'Accept': 'application/json;report-format=nested'
            },
            'queryParams': {
              'window': '1d'
            },
            'pathParams': {
              'reportId': 'taf_top_longest_user_agents,taf_top_shortest_user_agents'
            }
          },
          'title': 'Longest and Shortest User Agents'
        },
        'attributes': {
          'style': {
            'width': '100%',
            'marginRight': '33px'
          },
          'id': 'UserAgentDetails'
        },
        'children': [
          {
            'type': 'Table',
            'name': 'Table',
            'meta': {
              'showHeader': false,
              'title': 'Longest User Agents'
            },
            'attributes': {
              'style': {
                'width': '50%'
              },
              'id': 'LongestUserAgents'
            },
            'tableData': {
              'nestedResult': true,
              'emptyValueMessage': '{empty user agent}',
              'fieldMapping': [
                {
                  'reportId': 'taf_top_longest_user_agents',
                  'columns': [
                    {
                      'type': 'text',
                      'columnNameToDisplay': 'USER AGENT',
                      'data': [
                        {
                          'fieldName': 'data.http.userAgent'
                        }
                      ],
                      'style': {
                        'width': '70%'
                      }
                    },
                    {
                      'type': 'chart',
                      'columnNameToDisplay': 'CONNECTIONS',
                      'attributes': {
                        'id': 'connection',
                        'chartType': 'area2d',
                        'chartWidth': '100%',
                        'chartHeight': '75'
                      },
                      'data': [
                        {
                          'fieldName': 'count'
                        }
                      ],
                      'style': {
                        'width': '30%'
                      }
                    }
                  ]
                }
              ]
            },
            'tableOptions': {
              'sortable': ['USER AGENT'],
              'defaultSort': {
                'column': 'USER AGENT',
                'direction': 'asc'
              },
              'filterable': [],
              'itemsPerPage':5
            }
          },
          {
            'type': 'Table',
            'name': 'Table',
            'meta': {
              'showHeader': false,
              'title': 'Shortest User Agents'
            },
            'attributes': {
              'style': {
                'width': '50%',
                'paddingLeft': '2%'
              },
              'id': 'ShortestUserAgents'
            },
            'tableData': {
              'nestedResult': true,
              'emptyValueMessage': '{empty user agent}',
              'fieldMapping': [
                {
                  'reportId': 'taf_top_shortest_user_agents',
                  'columns': [
                    {
                      'type': 'text',
                      'columnNameToDisplay': 'USER AGENT',
                      'data': [
                        {
                          'fieldName': 'data.http.userAgent'
                        }
                      ],
                      'style': {
                        'width': '70%'
                      }
                    },
                    {
                      'type': 'chart',
                      'columnNameToDisplay': 'CONNECTIONS',
                      'attributes': {
                        'id': 'bandwidth',
                        'chartType': 'area2d',
                        'chartWidth': '100%',
                        'chartHeight': '75'
                      },
                      'data': [
                        {
                          'fieldName': 'count'
                        }
                      ],
                      'style': {
                        'width': '30%'
                      }
                    }
                  ]
                }
              ]
            },
            'tableOptions': {
              'sortable': ['USER AGENT'],
              'defaultSort': {
                'column': 'USER AGENT',
                'direction': 'asc'
              },
              'filterable': [],
              'itemsPerPage':5
            }
          }
        ]
      }
    ]*/
    /*,
    [
      {
        'id': '1795',
        'type': 'AlertDetails',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/alert/{alertId}',
            'queryParams': {
              'window': ''
            }
          },
          'title': 'Alert Details'
        },
        'name': 'AlertDetails',
        'attributes': {
          'style': {
            'width': '100%'
          }
        }
      }
    ],
    [
      {
        'id': '1801',
        'type': 'Table',
        'name': 'Table',
        'meta': {
          'showHeader': true,
          'showSearch': true,
          'api': {
            'path': '/api/alert/traffic',
            'queryParams': {
              'window': '1w',
              'count': 25,
              'date': '2016-07-04T07:34:22.616',
              'filter': '((source.ip%20=%20117.21.191.2%20AND%20destination.ip%20=%20172.31.9.170%20AND%20(type%20=%20conn%20AND%20source.reputation)))',
              'from': 0
            },
            'pathParams': {
              // 'reportId': 'taf_alert_highpriority'
            }
          },
          'title': 'Traffic Details'
        },
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'traffic-details'
        },
        'tableData': {
          'fieldMapping': [
            {
              'reportId': 'taf_alert_highpriority',
              'columns': [
                {
                  'type': 'text',
                  'columnNameToDisplay': 'Type',
                  'data': [
                    {
                      'fieldName': 'type'
                    }
                  ],
                  'style': {
                    'width': '10%',
                    'textTransform': 'capitalize'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DATE',
                  'data': [
                    {
                      'fieldName': 'date',
                      'displayName': 'date'
                    }
                  ],
                  'style': {
                    'width': '15%',
                    'textAlign': 'center'
                  }
                },
                {
                  'type': 'text',
                  'columnNameToDisplay': 'DETAILS',
                  'data': [
                    {
                      'fieldName': 'source.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'source.port',
                      'displayName': 'port'
                    },
                    {
                      'fieldName': 'destination.ip',
                      'displayName': 'IP'
                    },
                    {
                      'fieldName': 'destination.country',
                      'displayName': 'countryFlag'
                    },
                    {
                      'fieldName': 'destination.port',
                      'displayName': 'port'
                    }
                  ],
                  'style': {
                    'width': '70%'
                  }
                }
              ]
            }
          ]
        },
        'tableOptions': {
          'sortable': [
            'DATE'
          ],
          'defaultSort': {
            'column': 'RANK SCORE',
            'direction': 'desc'
          },
          'filterable': [
            'DATE',
            'DETAILS'
          ],
          'itemsPerPage': 10
        }
      }
    ]*/
  ]
};

export default staticLayout;
