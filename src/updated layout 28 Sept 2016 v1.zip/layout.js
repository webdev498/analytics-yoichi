const staticLayout = {
  "layout": [
    /*[
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_alert_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#F69275"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #F69275"
          }
        },
        "id": "1",
        "type": "MetricsCard",
        "title": "High Priority Alerts",
        "kibana": {
          "pathParams": [
            "alerts-score"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "scoreRange": ""
          }
        }
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_malware_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#F69275"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #F69275"
          }
        },
        "id": "2",
        "type": "MetricsCard",
        "title": "High Priority Malware"
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_event_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#2bd8d0"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #2bd8d0"
          }
        },
        "id": "3",
        "type": "MetricsCard",
        "title": "Events Processed",
        "kibana": {
          "pathParams": [
            "traffic-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": ""
          }
        }
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_asset_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#2bd8d0"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #2bd8d0"
          }
        },
        "id": "4",
        "type": "MetricsCard",
        "title": "Assets Monitored",
        "kibana": {
          "pathParams": [
            "assets-all"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": ""
          }
        }
      }
    ],*/
    /*[
      {
        "id": "recent-alerts",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "showSearch": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "count": 200
            },
            "pathParams": {
              "reportId": "taf_alert_highpriority"
            }
          },
          "title": "Recent Alerts"
        },
        "openAlertDetails": true,
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "RecentAlerts"
        },
        "tableData": {
          "fieldMapping": [
            {
              "reportId": "taf_alert_highpriority",
              "columns": [
                {
                  "type": "scoreWidget",
                  "columnNameToDisplay": "RANK SCORE",
                  "data": [
                    {
                      "fieldName": "data.rank_alert.score"
                    }
                  ],
                  "style": {
                    "width": "12%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "DATE",
                  "data": [
                    {
                      "fieldName": "date",
                      "displayName": "date"
                    }
                  ],
                  "style": {
                    "width": "10%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "DETAILS",
                  "data": [
                    {
                      "fieldName": "data.rank_alert.description",
                      "displayName": "description"
                    },
                    {
                      "fieldName": "data.rank_alert.message",
                      "displayName": ""
                    }
                  ],
                  "style": {
                    "width": "38%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "SOURCE",
                  "data": [
                    {
                      "fieldName": "source.ip",
                      "displayName": "IP"
                    },
                    {
                      "fieldName": "source.port",
                      "displayName": "port"
                    },
                    {
                      "fieldName": "source.country",
                      "displayName": "countryFlag"
                    },
                    {
                      "fieldName": "source.name",
                      "displayName": "Machine"
                    },
                    {
                      "fieldName": "source.owner",
                      "displayName": "Owner"
                    },
                    {
                      "fieldName": "source.asn",
                      "displayName": "ASN"
                    },
                    {
                      "fieldName": "source.assets",
                      "displayName": "Users"
                    }
                  ],
                  "style": {
                    "width": "20%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "DESTINATION",
                  "data": [
                    {
                      "fieldName": "destination.ip",
                      "displayName": "IP"
                    },
                    {
                      "fieldName": "destination.port",
                      "displayName": "port"
                    },
                    {
                      "fieldName": "destination.country",
                      "displayName": "countryFlag"
                    },
                    {
                      "fieldName": "destination.name",
                      "displayName": "Name"
                    },
                    {
                      "fieldName": "destination.owner",
                      "displayName": "Owner"
                    },
                    {
                      "fieldName": "destination.asn",
                      "displayName": "ASN"
                    },
                    {
                      "fieldName": "destination.assets",
                      "displayName": "Users"
                    }
                  ],
                  "style": {
                    "width": "20%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "sortable": [
            "RANK SCORE",
            "DATE",
            "DETAILS",
            "SOURCE",
            "DESTINATION"
          ],
          "defaultSort": {
            "column": "RANK SCORE",
            "direction": "desc"
          },
          "filterable": [
            "DATE",
            "DETAILS",
            "SOURCE",
            "DESTINATION"
          ],
          "itemsPerPage": 5
        }
      }
    ],
    [
      {
        "id": "alert-by-type",
        "type": "ParetoChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_threat_trend"
            }
          },
          "title": "Alert by type"
        },
        "attributes": {
          "style": {
            "width": "50%",
            "marginRight": "33px"
          },
          "id": "AlertByType",
          "chartWidth": "100%",
          "chartHeight": "350"
        },
        "chartOptions": {
          "pYAxisname": "ALERT COUNT",
          "xAxisname": "ALERT TYPES"
        },
        "chartData": {
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_threat_trend",
              "columns": [
                "data.rank_alert.category"
              ]
            },
            {
              "axis": "y",
              "reportId": "taf_threat_trend",
              "columns": [
                "date"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "alerts-type"
          ],
          "queryParams": {
            "type": "",
            "window": ""
          }
        }
      },
      {
        "id": "alert-priority-chart",
        "type": "MultiSeriesCombiChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_alert_priority_time"
            }
          },
          "title": "Alert priority"
        },
        "attributes": {
          "style": {
            "width": "50%"
          },
          "id": "AlertPriorityChart",
          "chartWidth": "100%",
          "chartHeight": "350",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "yAxisName": "ALERT COUNT",
          "drawAnchors": "1",
          "legendPosition": "right",
          "linealpha": "0"
        },
        "chartData": {
          "combinedResult": false,
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_alert_priority_time",
              "columns": [
                "date"
              ]
            },
            {
              "axis": "y",
              "seriesOptions": {
                "renderas": "Line",
                "lineThickness": "0",
                "drawanchors": "1",
                "anchorradius": "5",
                "anchorsides": [
                  "0",
                  "0",
                  "0"
                ],
                "anchorBorderColor": [
                  "#90d0a4",
                  "#fcc875",
                  "#f69275"
                ],
                "anchorbgcolor": [
                  "#90d0a4",
                  "#fcc875",
                  "#f69275"
                ]
              },
              "reportId": "taf_alert_priority_time",
              "columns": [
                "data.rank_alert.score",
                "count"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "alerts-score"
          ],
          "queryParams": {
            "scoreRange": "",
            "fromAndToBasedOnClickedDate": ""
          }
        }
      }
    ],
    [
      {
        "id": "outgoing-traffic-heatMap",
        "type": "Compound",
        "name": "Compound",
        "meta": {
          "showHeader": true,
          "title": "Outgoing Traffic HeatMap"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "OutgoingTrafficHeatMap"
        },
        "children": [
          {
            "type": "WorldMap",
            "id": "Outgoingworld-map",
            "meta": {
              "showHeader": false,
              "title": "Outgoing Traffic Heatmap",
              "subTitle": "NUMBER OF OUTGOING CONNECTIONS BY COUNTRY",
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "queryParams": {
                  "window": ""
                },
                "pathParams": {
                  "reportId": "taf_dest_countries,taf_dest_bad_reputation_countries"
                }
              }
            },
            "attributes": {
              "style": {
                "width": "70%",
                "marginRight": "33px"
              },
              "id": "OutgoingTrafficWorldMap",
              "loaderStyle": {
                "marginTop": "-30px"
              },
              "chartWidth": "100%",
              "chartHeight": "450",
              "legendStyle": {
                "width": "10%",
                "marginLeft": "-10%"
              }
            },
            "chartOptions": {
            },
            "chartData": {
              "fieldMapping": [
                {
                  "reportId": "taf_dest_bad_reputation_countries",
                  "columns": [
                    "destination.country",
                    "pos_x",
                    "pos_y",
                    "connections"
                  ],
                  "connection": "malicious"
                },
                {
                  "reportId": "taf_dest_countries",
                  "columns": [
                    "destination.country",
                    "pos_x",
                    "pos_y",
                    "connections"
                  ],
                  "connection": "secure"
                }
              ]
            },
            "kibana": {
              "pathParams": [
                "destination-country-details"
              ],
              "queryParams": {
                "country": "",
                "fromAndToBasedOnToday": ""
              }
            }
          },
          {
            "id": "OutgoingTrafficHeatMapLegends",
            "type": "Compound",
            "name": "Compound",
            "meta": {
              "showHeader": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "queryParams": {
                  "window": ""
                },
                "pathParams": {
                  "reportId": "taf_dest_countries,taf_dest_bad_reputation_countries"
                }
              }
            },
            "attributes": {
              "style": {
                "width": "30%",
                "marginTop": "-30px"
              },
              "id": "OutgoingTrafficHeatMapLegends"
            },
            "innerStyle": {
              "flexWrap": "wrap",
              "flexDirection": "column"
            },
            "children": [
              {
                "type": "HorizontalBarChart",
                "meta": {
                  "showHeader": false,
                  "parentWrap": false,
                  "title": "TOP 5 CONNECTIONS"
                },
                "attributes": {
                  "id": "OutgoingTopCountries",
                  "style": {
                    "marginTop": "35px"
                  },
                  "chartCaption": {
                    "position": "absolute"
                  },
                  "chartBorder": {},
                  "chartWidth": "100%",
                  "chartHeight": "200"
                },
                "chartOptions": {
                },
                "chartData": {
                  "multipleReportIds": false,
                  "displayTopFive": true,
                  "showTrendLines": false,
                  "fieldMapping": [
                    {
                      "reportId": "taf_dest_bad_reputation_countries",
                      "columns": [
                        "country_name",
                        "connections"
                      ],
                      "connection": "malicious"
                    },
                    {
                      "reportId": "taf_dest_countries",
                      "columns": [
                        "country_name",
                        "connections"
                      ],
                      "connection": "secure"
                    }
                  ]
                }
              },
              {
                "type": "HorizontalBarChart",
                "meta": {
                  "showHeader": false,
                  "parentWrap": false,
                  "title": "TOP 5 BANDWIDTH",
                  "subTitle": "(in bytes)"
                },
                "attributes": {
                  "id": "OutgoingTopBandwidth",
                  "style": {
                    "marginTop": "35px"
                  },
                  "chartCaption": {
                    "position": "absolute"
                  },
                  "chartWidth": "100%",
                  "chartHeight": "200"
                },
                "chartOptions": {
                },
                "chartData": {
                  "multipleReportIds": false,
                  "displayTopFive": true,
                  "showTrendLines": false,
                  "fieldMapping": [
                    {
                      "reportId": "taf_dest_bad_reputation_countries",
                      "columns": [
                        "country_name",
                        "bandwidth"
                      ],
                      "connection": "malicious"
                    },
                    {
                      "reportId": "taf_dest_countries",
                      "columns": [
                        "country_name",
                        "bandwidth"
                      ],
                      "connection": "secure"
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ],
    [
      {
        "id": "incoming-traffic-heatMap",
        "type": "Compound",
        "name": "Compound",
        "meta": {
          "showHeader": true,
          "title": "Incoming Traffic HeatMap"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "IncomingTrafficHeatMap"
        },
        "children": [
          {
            "type": "WorldMap",
            "id": "world-map",
            "meta": {
              "showHeader": false,
              "title": "Incoming Traffic Heatmap",
              "subTitle": "NUMBER OF INCOMING CONNECTIONS BY COUNTRY",
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "queryParams": {
                  "window": ""
                },
                "pathParams": {
                  "reportId": "taf_source_countries,taf_source_bad_reputation_countries"
                }
              }
            },
            "attributes": {
              "style": {
                "width": "70%",
                "marginRight": "33px"
              },
              "id": "IncomingTrafficWorldMap",
              "loaderStyle": {
                "marginTop": "-30px"
              },
              "chartWidth": "100%",
              "chartHeight": "450",
              "legendStyle": {
                "width": "10%",
                "marginLeft": "-10%"
              }
            },
            "chartOptions": {
            },
            "chartData": {
              "fieldMapping": [
                {
                  "reportId": "taf_source_bad_reputation_countries",
                  "columns": [
                    "source.country",
                    "pos_x",
                    "pos_y",
                    "connections"
                  ],
                  "connection": "malicious"
                },
                {
                  "reportId": "taf_source_countries",
                  "columns": [
                    "source.country",
                    "pos_x",
                    "pos_y",
                    "connections"
                  ],
                  "connection": "secure"
                }
              ]
            },
            "kibana": {
              "pathParams": [
                "source-country-details"
              ],
              "queryParams": {
                "country": "",
                "fromAndToBasedOnToday": ""
              }
            }
          },
          {
            "id": "IncomingTrafficHeatMapLegends",
            "type": "Compound",
            "name": "Compound",
            "meta": {
              "showHeader": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "queryParams": {
                  "window": ""
                },
                "pathParams": {
                  "reportId": "taf_source_countries,taf_source_bad_reputation_countries"
                }
              }
            },
            "attributes": {
              "style": {
                "width": "30%",
                "marginTop": "-30px"
              },
              "id": "IncomingTrafficHeatMapLegends"
            },
            "innerStyle": {
              "flexWrap": "wrap",
              "flexDirection": "column"
            },
            "children": [
              {
                "type": "HorizontalBarChart",
                "meta": {
                  "showHeader": false,
                  "parentWrap": false,
                  "title": "TOP 5 CONNECTIONS"
                },
                "attributes": {
                  "id": "IncomingTopCountries",
                  "style": {
                    "marginTop": "35px"
                  },
                  "chartCaption": {
                    "position": "absolute"
                  },
                  "chartBorder": {},
                  "chartWidth": "100%",
                  "chartHeight": "200"
                },
                "chartOptions": {
                },
                "chartData": {
                  "multipleReportIds": false,
                  "displayTopFive": true,
                  "showTrendLines": false,
                  "fieldMapping": [
                    {
                      "reportId": "taf_source_bad_reputation_countries",
                      "columns": [
                        "country_name",
                        "connections"
                      ],
                      "connection": "malicious"
                    },
                    {
                      "reportId": "taf_source_countries",
                      "columns": [
                        "country_name",
                        "connections"
                      ],
                      "connection": "secure"
                    }
                  ]
                }
              },
              {
                "type": "HorizontalBarChart",
                "meta": {
                  "showHeader": false,
                  "parentWrap": false,
                  "title": "TOP 5 BANDWIDTH",
                  "subTitle": "(in bytes)"
                },
                "attributes": {
                  "id": "IncomingTopBandwidth",
                  "style": {
                    "marginTop": "35px"
                  },
                  "chartCaption": {
                    "position": "absolute"
                  },
                  "chartWidth": "100%",
                  "chartHeight": "200"
                },
                "chartOptions": {
                },
                "chartData": {
                  "multipleReportIds": false,
                  "displayTopFive": true,
                  "showTrendLines": false,
                  "fieldMapping": [
                    {
                      "reportId": "taf_source_bad_reputation_countries",
                      "columns": [
                        "country_name",
                        "bandwidth"
                      ],
                      "connection": "malicious"
                    },
                    {
                      "reportId": "taf_source_countries",
                      "columns": [
                        "country_name",
                        "bandwidth"
                      ],
                      "connection": "secure"
                    }
                  ]
                }
              }
            ]
          }
        ]
      }
    ],
    [
      {
        "id": "histogram-chart1",
        "type": "MultiSeriesCombiChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_stats_histogram,taf_connections_by_protocol"
            }
          },
          "title": "Incoming Bandwidth",
          "subTitle": "(in bytes)"
        },
        "attributes": {
          "style": {
            "width": "50%",
            "marginRight": "33px"
          },
          "id": "HistogramChart1",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "xAxisName": "TIME",
          "yAxisName": "INCOMING BANDWIDTH",
          "lineThickness": "2",
          "paletteColors": "#C9EDDF, #60E2DC",
          "drawAnchors": "0"
        },
        "chartData": {
          "combinedResult": true,
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_stats_histogram",
              "columns": [
                "date"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Historical Incoming Bandwidth",
              "renderas": "Area",
              "reportId": "taf_stats_histogram",
              "columns": [
                "bytes_in[1]"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Current Incoming Bandwidth",
              "renderas": "Line",
              "reportId": "taf_stats_histogram",
              "columns": [
                "bytes_in[0]"
              ]
            }
          ]
        }
      },
      {
        "id": "histogram-chart2",
        "type": "MultiSeriesCombiChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_stats_histogram,taf_connections_by_protocol"
            }
          },
          "title": "Outgoing Bandwidth",
          "subTitle": "(in bytes)"
        },
        "attributes": {
          "style": {
            "width": "50%"
          },
          "id": "HistogramChart2",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "xAxisName": "TIME",
          "yAxisName": "OUTGOING BANDWIDTH",
          "lineThickness": "2",
          "paletteColors": "#C9EDDF, #60E2DC",
          "drawAnchors": "0"
        },
        "chartData": {
          "combinedResult": true,
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_stats_histogram",
              "columns": [
                "date"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Historical Outgoing Bandwidth",
              "renderas": "Area",
              "reportId": "taf_stats_histogram",
              "columns": [
                "bytes_out[1]"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Current Outgoing Bandwidth",
              "renderas": "Line",
              "reportId": "taf_stats_histogram",
              "columns": [
                "bytes_out[0]"
              ]
            }
          ]
        }
      }
    ],
    [
      {
        "id": "histogram-chart3",
        "type": "MultiSeriesCombiChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_stats_histogram,taf_connections_by_protocol"
            }
          },
          "title": "No. of Connections"
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "HistogramChart3",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "xAxisName": "TIME",
          "yAxisName": "NO. OF CONNECTIONS",
          "lineThickness": "2",
          "paletteColors": "#C9EDDF, #60E2DC",
          "drawAnchors": "0"
        },
        "chartData": {
          "combinedResult": true,
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_stats_histogram",
              "columns": [
                "date"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Historical Connections",
              "renderas": "Area",
              "reportId": "taf_stats_histogram",
              "columns": [
                "conn[1]"
              ]
            },
            {
              "axis": "y",
              "seriesname": "Current Connections",
              "renderas": "Line",
              "reportId": "taf_stats_histogram",
              "columns": [
                "conn[0]"
              ]
            }
          ]
        }
      },
      {
        "id": "top-connections-by-protocol",
        "type": "HorizontalBarChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_stats_histogram,taf_connections_by_protocol"
            }
          },
          "title": "Top Connections By Protocol"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "TopConnectionsByProtocol",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "showLabels": "1",
          "showValues": "0",
          "singleLineCharacters": "27"
        },
        "chartData": {
          "multipleReportIds": false,
          "showTrendLines": false,
          "fieldMapping": [
            {
              "reportId": "taf_connections_by_protocol",
              "columns": [
                "protocol.service",
                "date"
              ]
            }
          ]
        }
      }
    ],
    [
      {
        "id": "longest-connections",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_longest_connections"
            }
          },
          "title": "Longest Connections"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "LongestConnections"
        },
        "tableData": {
          "fieldMapping": [
            {
              "reportId": "taf_top_longest_connections",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "END DATE",
                  "data": [
                    {
                      "fieldName": "date",
                      "displayName": "date"
                    }
                  ],
                  "style": {
                    "width": "10%"
                  }
                },
                {
                  "type": "durationWidget",
                  "columnNameToDisplay": "DURATION",
                  "data": [
                    {
                      "fieldName": "data.conn.duration",
                      "displayName": "duration"
                    }
                  ],
                  "style": {
                    "width": "15%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "DETAILS",
                  "data": [
                    {
                      "fieldName": "protocol.service",
                      "displayName": "title"
                    },
                    {
                      "fieldName": "data.conn.reqBytes",
                      "displayName": "Incoming bytes"
                    },
                    {
                      "fieldName": "data.conn.respBytes",
                      "displayName": "Outcoming bytes"
                    }
                  ],
                  "style": {
                    "width": "35%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "SOURCE",
                  "data": [
                    {
                      "fieldName": "source.ip",
                      "displayName": "IP"
                    },
                    {
                      "fieldName": "source.port",
                      "displayName": "port"
                    },
                    {
                      "fieldName": "source.country",
                      "displayName": "countryFlag"
                    },
                    {
                      "fieldName": "source.name",
                      "displayName": "Machine"
                    },
                    {
                      "fieldName": "source.owner",
                      "displayName": "Owner"
                    },
                    {
                      "fieldName": "source.asn",
                      "displayName": "ASN"
                    },
                    {
                      "fieldName": "source.assets",
                      "displayName": "Users"
                    }
                  ],
                  "style": {
                    "width": "20%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "DESTINATION",
                  "data": [
                    {
                      "fieldName": "destination.ip",
                      "displayName": "IP"
                    },
                    {
                      "fieldName": "destination.port",
                      "displayName": "port"
                    },
                    {
                      "fieldName": "destination.country",
                      "displayName": "countryFlag"
                    },
                    {
                      "fieldName": "destination.name",
                      "displayName": "Machine"
                    },
                    {
                      "fieldName": "destination.owner",
                      "displayName": "Owner"
                    },
                    {
                      "fieldName": "destination.asn",
                      "displayName": "ASN"
                    },
                    {
                      "fieldName": "destination.assets",
                      "displayName": "Users"
                    }
                  ],
                  "style": {
                    "width": "20%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "sortable": [
            "END DATE",
            "DURATION",
            "DETAILS",
            "SOURCE",
            "DESTINATION"
          ],
          "defaultSort": {
            "column": "DURATION",
            "direction": "asc"
          },
          "filterable": [],
          "itemsPerPage": 5
        },
        "kibana": {
          "pathParams": [
            "connection-details"
          ],
          "queryParams": {
            "correlationIds": "correlationIds[0]"
          }
        }
      }
    ],
    [
      {
        "id": "pie-chart-connections",
        "type": "PieChart",
        "meta": {
          "showHeader": true,
          "title": "Top Connections",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "legend": [
            "Connections",
            "Used by",
            "Assets"
          ]
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "PieChartConnections"
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "date"
              ]
            },
            {
              "reportId": "taf_top_talkers_connections",
              "columns": [
                "connections"
              ]
            }
          ]
        }
      },
      {
        "id": "horizontal-bar-chart-connections",
        "type": "HorizontalBarChart",
        "meta": {
          "showHeader": true,
          "title": "Top IPs Using The Most Connections",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          }
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "HorizontalBarChartConnections",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "numberSuffix": "%",
          "showLabels": "1",
          "showValues": "0"
        },
        "chartData": {
          "multipleReportIds": true,
          "showTrendLines": true,
          "trendLines": [
            {
              "line": [
                {
                  "color": "#f69275",
                  "valueOnRight": "1",
                  "dashed": "1",
                  "dashLen": "4",
                  "dashGap": "2"
                }
              ]
            }
          ],
          "reportId": "taf_top_talkers_connections",
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "date"
              ]
            },
            {
              "reportId": "taf_top_talkers_connections",
              "columns": [
                "connections"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "ip-connection-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "ip": ""
          }
        }
      }
    ],
    [
      {
        "id": "pie-chart-bandwidth",
        "type": "PieChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "title": "Top Bandwidth",
          "legend": [
            "Bandwidth ",
            "Used by",
            "Assets"
          ]
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "PieChartBandwidth"
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "bandwidth"
              ]
            },
            {
              "reportId": "taf_top_talkers_bandwidth",
              "columns": [
                "bandwidth"
              ]
            }
          ]
        }
      },
      {
        "id": "horizontal-bar-chart-bandwidth",
        "type": "HorizontalBarChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "title": "Top IPs Using The Highest Bandwidth"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "HorizontalBarChartBandwidth",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "numberSuffix": "%",
          "showLabels": "1",
          "showValues": "0"
        },
        "chartData": {
          "multipleReportIds": true,
          "showTrendLines": true,
          "trendLines": [
            {
              "line": [
                {
                  "color": "#f69275",
                  "valueOnRight": "1",
                  "dashed": "1",
                  "dashLen": "4",
                  "dashGap": "2"
                }
              ]
            }
          ],
          "reportId": "taf_top_talkers_bandwidth",
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "bandwidth"
              ]
            },
            {
              "reportId": "taf_top_talkers_bandwidth",
              "columns": [
                "bandwidth"
              ]
            }
          ]
        }
      }
    ],
    [
      {
        "id": "user-agent-length",
        "type": "ScatterChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_user_agent_unique"
            }
          },
          "title": "User Agent Details"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "UserAgentLength",
          "chartWidth": "100%",
          "chartHeight": "300"
        },
        "chartOptions": {
          "xAxisName": "USER AGENT LENGTH",
          "yAxisName": "CONNECTION COUNT"
        },
        "chartData": {
          "fieldMapping": [
            {
              "seriesname": "User Agent Length",
              "reportId": "taf_user_agent_unique",
              "columns": [
                "data.http.__info.userAgentLen",
                "date"
              ]
            }
          ]
        }
      }
    ],
    [
      {
        "id": "longest-user-agents",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "headers": {
              "Accept": "application/json;report-format=nested"
            },
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_longest_user_agents,taf_top_shortest_user_agents"
            }
          },
          "title": "Longest User Agents"
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "LongestUserAgents"
        },
        "tableData": {
          "nestedResult": true,
          "emptyValueMessage": "(Empty)",
          "fieldMapping": [
            {
              "reportId": "taf_top_longest_user_agents",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "LONGEST USER AGENT",
                  "data": [
                    {
                      "fieldName": "data.http.userAgent"
                    }
                  ],
                  "style": {
                    "width": "70%"
                  }
                },
                {
                  "type": "chart",
                  "columnNameToDisplay": "CONNECTIONS",
                  "attributes": {
                    "id": "connection",
                    "chartType": "area2d",
                    "chartWidth": "100%",
                    "chartHeight": "75"
                  },
                  "data": [
                    {
                      "fieldName": "count"
                    }
                  ],
                  "style": {
                    "width": "30%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "itemsPerPage": 5
        }
      },
      {
        "id": "shortest-user-agents",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "headers": {
              "Accept": "application/json;report-format=nested"
            },
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_longest_user_agents,taf_top_shortest_user_agents"
            }
          },
          "title": "Shortest User Agents"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "ShortestUserAgents"
        },
        "tableData": {
          "nestedResult": true,
          "emptyValueMessage": "(Empty)",
          "fieldMapping": [
            {
              "reportId": "taf_top_shortest_user_agents",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "SHORTEST USER AGENT",
                  "data": [
                    {
                      "fieldName": "data.http.userAgent"
                    }
                  ],
                  "style": {
                    "width": "70%"
                  }
                },
                {
                  "type": "chart",
                  "columnNameToDisplay": "CONNECTIONS",
                  "attributes": {
                    "id": "bandwidth",
                    "chartType": "area2d",
                    "chartWidth": "100%",
                    "chartHeight": "75"
                  },
                  "data": [
                    {
                      "fieldName": "count"
                    }
                  ],
                  "style": {
                    "width": "30%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "itemsPerPage": 5
        }
      }
    ],*/
    [
      {
        "id": "network-graph",
        "type": "NetworkGraph",
        "name": "NetworkGraph",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/graph/{alertId}",
            "queryParams": {
            },
            "pathParams": {
              "alertId": "OikKAfhyT2lrS0FmaERiR2wyWlV3eU1UTXVNVEk0TGpneExqWTJTekUzTWk0ek1TNDVMakUyT2ZrQ2xpdmVSYmFkLXJlcHV0YXRpb24uZnJvbfk"
            }
          },
          "title": "Overview"
        },
        "attributes": {
          "style": {
            "height": "725px",
            "width": "100%"
          },
          "id": "NetworkGraph"
        }
      }
    ],
    [
      {
        "id": "timeline-graph",
        "type": "TimelineGraph",
        "name": "TimelineGraph",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "1w",
              "count": 200
            },
            "pathParams": {
              "reportId": "taf_alert_highpriority"
            }
          },
          "title": "Timeline"
        },
        "attributes": {
          "style": {
            "height": "1725px",
            "width": "100%",
            "backgroundColor": "#F7F7F9"
          },
          "id": "TimelineGraph"
        }
      }
    ],
    [
      {
        "id": "extend-network-graph",
        "type": "ExtendNetworkGraph",
        "name": "ExtendNetworkGraph",
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
            },
            "pathParams": {
              "reportId": "OikKAfhyT2lrS0FmaERiR2wyWlV3eU1UTXVNVEk0TGpneExqWTJTekUzTWk0ek1TNDVMakUyT2ZrQ2xpdmVSYmFkLXJlcHV0YXRpb24uZnJvbfk"
            }
          },
          "title": "Overview"
        },
        "attributes": {
          "style": {
            "height": "725px",
            "width": "100%"
          },
          "id": "NetworkGraph"
        }
      }
    ]
  ]
};

const newSummaryPage = {
  "layout": [
    [
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_alert_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#F69275"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #F69275"
          }
        },
        "id": "1",
        "type": "MetricsCard",
        "title": "High Priority Alerts",
        "kibana": {
          "pathParams": [
            "alerts-score"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "scoreRange": ""
          }
        }
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_malware_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#F69275"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #F69275"
          }
        },
        "id": "2",
        "type": "MetricsCard",
        "title": "High Priority Malware"
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_event_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#2bd8d0"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #2bd8d0"
          }
        },
        "id": "3",
        "type": "MetricsCard",
        "title": "Events Processed",
        "kibana": {
          "pathParams": [
            "traffic-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": ""
          }
        }
      },
      {
        "meta": {
          "showHeader": false,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "pathParams": {
              "reportId": "taf_asset_count_time_shifted"
            },
            "queryParams": {
              "window": ""
            }
          }
        },
        "name": "MetricsCard",
        "attributes": {
          "countStyle": {
            "color": "#2bd8d0"
          },
          "style": {
            "marginRight": "3px",
            "width": "25%",
            "borderTop": "6px solid #2bd8d0"
          }
        },
        "id": "4",
        "type": "MetricsCard",
        "title": "Assets Monitored",
        "kibana": {
          "pathParams": [
            "assets-all"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": ""
          }
        }
      }
    ],
    [
      {
        "id": "alert-by-type",
        "type": "ParetoChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_threat_trend"
            }
          },
          "title": "Alert by type"
        },
        "attributes": {
          "style": {
            "width": "50%",
            "marginRight": "33px"
          },
          "id": "AlertByType",
          "chartWidth": "100%",
          "chartHeight": "350"
        },
        "chartOptions": {
          "pYAxisname": "ALERT COUNT",
          "xAxisname": "ALERT TYPES"
        },
        "chartData": {
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_threat_trend",
              "columns": [
                "data.rank_alert.category"
              ]
            },
            {
              "axis": "y",
              "reportId": "taf_threat_trend",
              "columns": [
                "date"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "alerts-type"
          ],
          "queryParams": {
            "type": "",
            "window": ""
          }
        }
      },
      {
        "id": "top-attacked-entities ",
        "type": "ParetoChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_entity_with_alerts"
            }
          },
          "title": "Top Attacked Entities"
        },
        "attributes": {
          "style": {
            "width": "50%"
          },
          "id": "TopAttackedEntities",
          "chartWidth": "100%",
          "chartHeight": "350"
        },
        "chartOptions": {
          "pYAxisname": "ALERT COUNT",
          "xAxisname": "ENTITIES"
        },
        "chartData": {
          "fieldMapping": [
            {
              "axis": "x",
              "reportId": "taf_top_entity_with_alerts",
              "columns": [
                "destination.ip"
              ]
            },
            {
              "axis": "y",
              "reportId": "taf_top_entity_with_alerts",
              "columns": [
                "count"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "attacked-entity-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "ip": ""
          }
        }
      }
    ],
    [
      {
        "id": "pie-chart-connections",
        "type": "PieChart",
        "meta": {
          "showHeader": true,
          "title": "Top Connections",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "legend": [
            "Connections",
            "Used by",
            "Assets"
          ]
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "PieChartConnections"
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "date"
              ]
            },
            {
              "reportId": "taf_top_talkers_connections",
              "columns": [
                "connections"
              ]
            }
          ]
        }
      },
      {
        "id": "horizontal-bar-chart-connections",
        "type": "HorizontalBarChart",
        "meta": {
          "showHeader": true,
          "title": "Top IPs Using The Most Connections",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          }
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "HorizontalBarChartConnections",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "numberSuffix": "%",
          "showLabels": "1",
          "showValues": "0"
        },
        "chartData": {
          "multipleReportIds": true,
          "showTrendLines": true,
          "trendLines": [
            {
              "line": [
                {
                  "color": "#f69275",
                  "valueOnRight": "1",
                  "dashed": "1",
                  "dashLen": "4",
                  "dashGap": "2"
                }
              ]
            }
          ],
          "reportId": "taf_top_talkers_connections",
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "date"
              ]
            },
            {
              "reportId": "taf_top_talkers_connections",
              "columns": [
                "connections"
              ]
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "ip-connection-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "ip": ""
          }
        }
      }
    ],
    [
      {
        "id": "pie-chart-bandwidth",
        "type": "PieChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "title": "Top Bandwidth",
          "legend": [
            "Bandwidth ",
            "Used by",
            "Assets"
          ]
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "PieChartBandwidth"
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "bandwidth"
              ]
            },
            {
              "reportId": "taf_top_talkers_bandwidth",
              "columns": [
                "bandwidth"
              ]
            }
          ]
        }
      },
      {
        "id": "horizontal-bar-chart-bandwidth",
        "type": "HorizontalBarChart",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "timeShift": ""
            },
            "pathParams": {
              "reportId": "taf_total_usage,taf_top_talkers_connections,taf_top_talkers_bandwidth,taf_asset_count_time_shifted"
            }
          },
          "title": "Top IPs Using The Highest Bandwidth"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "HorizontalBarChartBandwidth",
          "chartCaption": {
            "display": "none"
          }
        },
        "chartOptions": {
          "numberSuffix": "%",
          "showLabels": "1",
          "showValues": "0"
        },
        "chartData": {
          "multipleReportIds": true,
          "showTrendLines": true,
          "trendLines": [
            {
              "line": [
                {
                  "color": "#f69275",
                  "valueOnRight": "1",
                  "dashed": "1",
                  "dashLen": "4",
                  "dashGap": "2"
                }
              ]
            }
          ],
          "reportId": "taf_top_talkers_bandwidth",
          "fieldMapping": [
            {
              "reportId": "taf_asset_count_time_shifted",
              "columns": [
                "0.0"
              ]
            },
            {
              "reportId": "taf_total_usage",
              "columns": [
                "bandwidth"
              ]
            },
            {
              "reportId": "taf_top_talkers_bandwidth",
              "columns": [
                "bandwidth"
              ]
            }
          ]
        }
      }
    ],
    [
      {
        "type": "WorldMap",
        "id": "Outgoingworld-map",
        "meta": {
          "showHeader": true,
          "title": "Outgoing Traffic Heatmap",
          "subTitle": "NUMBER OF OUTGOING CONNECTIONS BY COUNTRY",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_dest_countries,taf_dest_bad_reputation_countries"
            }
          }
        },
        "attributes": {
          "style": {
            "width": "50%",
            "marginRight": "33px"
          },
          "id": "OutgoingTrafficWorldMap",
          "loaderStyle": {
            "marginTop": "-30px"
          },
          "chartWidth": "100%",
          "chartHeight": "350",
          "chartCaption": {
          },
          "legendStyle": {
            "width": "15%",
            "marginLeft": "-15%"
          }
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_dest_bad_reputation_countries",
              "columns": [
                "destination.country",
                "pos_x",
                "pos_y",
                "connections"
              ],
              "connection": "malicious"
            },
            {
              "reportId": "taf_dest_countries",
              "columns": [
                "destination.country",
                "pos_x",
                "pos_y",
                "connections"
              ],
              "connection": "secure"
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "destination-country-details"
          ],
          "queryParams": {
            "country": "",
            "fromAndToBasedOnToday": ""
          }
        }
      },
      {
        "type": "WorldMap",
        "id": "world-map",
        "meta": {
          "showHeader": true,
          "title": "Incoming Traffic Heatmap",
          "subTitle": "NUMBER OF INCOMING CONNECTIONS BY COUNTRY",
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_source_countries,taf_source_bad_reputation_countries"
            }
          }
        },
        "attributes": {
          "style": {
            "width": "50%"
          },
          "id": "IncomingTrafficWorldMap",
          "loaderStyle": {
            "marginTop": "-30px"
          },
          "chartWidth": "100%",
          "chartHeight": "350",
          "chartCaption": {
          },
          "legendStyle": {
            "width": "15%",
            "marginLeft": "-15%"
          }
        },
        "chartOptions": {
        },
        "chartData": {
          "fieldMapping": [
            {
              "reportId": "taf_source_bad_reputation_countries",
              "columns": [
                "source.country",
                "pos_x",
                "pos_y",
                "connections"
              ],
              "connection": "malicious"
            },
            {
              "reportId": "taf_source_countries",
              "columns": [
                "source.country",
                "pos_x",
                "pos_y",
                "connections"
              ],
              "connection": "secure"
            }
          ]
        },
        "kibana": {
          "pathParams": [
            "source-country-details"
          ],
          "queryParams": {
            "country": "",
            "fromAndToBasedOnToday": ""
          }
        }
      }
    ],
    [
      {
        "id": "least-used-software-details",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_least_used_software"
            }
          },
          "title": "Least Used Software Details"
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "LeastUsedSoftwareDetails"
        },
        "tableData": {
          "emptyValueMessage": "(Empty)",
          "fieldMapping": [
            {
              "reportId": "taf_least_used_software",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "SOFTWARE NAME",
                  "data": [
                    {
                      "fieldName": "data.software.version"
                    }
                  ],
                  "style": {
                    "width": "80%"
                  }
                },
                {
                  "type": "text",
                  "columnNameToDisplay": "COUNT",
                  "data": [
                    {
                      "fieldName": "count"
                    }
                  ],
                  "style": {
                    "width": "20%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "itemsPerPage": 5
        },
        "kibana": {
          "pathParams": [
            "software-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": ""
          }
        }
      },
      {
        "id": "successful-logins",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "headers": {
              "Accept": "application/json;report-format=nested"
            },
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_successful_logins"
            }
          },
          "title": "Successful Logins"
        },
        "attributes": {
          "style": {
            "width": "100%",
            "marginRight": "33px"
          },
          "id": "SuccessfulLogins"
        },
        "tableData": {
          "nestedResult": true,
          "emptyValueMessage": "(Empty)",
          "fieldMapping": [
            {
              "reportId": "taf_top_successful_logins",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "USER NAME",
                  "data": [
                    {
                      "fieldName": "data.auth.username"
                    }
                  ],
                  "style": {
                    "width": "70%"
                  }
                },
                {
                  "type": "chart",
                  "columnNameToDisplay": "LOGINS",
                  "attributes": {
                    "id": "SuccessfulLogins",
                    "chartType": "area2d",
                    "chartWidth": "100%",
                    "chartHeight": "75"
                  },
                  "data": [
                    {
                      "fieldName": "count"
                    }
                  ],
                  "style": {
                    "width": "30%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "itemsPerPage": 5
        },
        "kibana": {
          "pathParams": [
            "login-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "username": "data.auth.username",
            "status": "success"
          }
        }
      },
      {
        "id": "failed-logins",
        "type": "Table",
        "name": "Table",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "headers": {
              "Accept": "application/json;report-format=nested"
            },
            "queryParams": {
              "window": ""
            },
            "pathParams": {
              "reportId": "taf_top_failed_logins"
            }
          },
          "title": "Failed Logins"
        },
        "attributes": {
          "style": {
            "width": "100%"
          },
          "id": "FailedLogins"
        },
        "tableData": {
          "nestedResult": true,
          "emptyValueMessage": "(Empty)",
          "fieldMapping": [
            {
              "reportId": "taf_top_failed_logins",
              "columns": [
                {
                  "type": "text",
                  "columnNameToDisplay": "USER NAME",
                  "data": [
                    {
                      "fieldName": "data.auth.username"
                    }
                  ],
                  "style": {
                    "width": "70%"
                  }
                },
                {
                  "type": "chart",
                  "columnNameToDisplay": "LOGINS",
                  "attributes": {
                    "id": "FailedLogins",
                    "chartType": "area2d",
                    "chartWidth": "100%",
                    "chartHeight": "75"
                  },
                  "data": [
                    {
                      "fieldName": "count"
                    }
                  ],
                  "style": {
                    "width": "30%"
                  }
                }
              ]
            }
          ]
        },
        "tableOptions": {
          "itemsPerPage": 5
        },
        "kibana": {
          "pathParams": [
            "login-details"
          ],
          "queryParams": {
            "fromAndToBasedOnToday": "",
            "username": "data.auth.username",
            "status": "fail"
          }
        }
      }
    ]
  ]
};

const alertDetails = {
  'layout': [
    [
      {
        'id': 'alert-detail',
        'type': 'AlertDetailsNew',
        'meta': {
          'showHeader': true,
          'showRefresh': false,
          'api': {
            'path': '/api/alert/{alertId}',
            'pathParams': {
              'alertId': ':pathParam'
            },
            'queryParams': {
              'window': '',
              'date': ':pathParam'
            }
          },
          'title': 'Alert Detail'
        },
        'name': 'AlertDetail',
        'attributes': {
          'style': {
            'width': '20%',
            'backgroundColor': '#F7F7F9'
          }
        }
      },
      {
        'id': 'network-graph',
        'type': 'NetworkGraph',
        'name': 'NetworkGraph',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/graph/{alertId}',
            'queryParams': {
            },
            'pathParams': {
              'alertId': ':pathParam'
            }
          },
          'title': 'Overview'
        },
        'attributes': {
          'style': {
            'height': '725px',
            'width': '80%'
          },
          'id': 'NetworkGraph'
        }
      }

    ]
  ]
};

const assetDetails = {
  'layout': [
    [
      {
        'id': 'asset-detail',
        'type': 'AssetDetails',
        'meta': {
          'showHeader': true,
          'api': [
            {
              'path': '/api/entity/{type}/{assetId}',
              'pathParams': {
                'assetId': ':pathParam',
                'type': ':pathParam'
              },
              'queryParams': {},
              'id': 'assetDetail'
            },
            {
              'path': '/api/analytics/reporting/execute/{reportId}',
              'pathParams': {
                'reportId': 'taf_asset_session_count,taf_asset_internal_resource_count,taf_asset_total_incoming_bandwidth_external,taf_asset_total_incoming_bandwidth_internal,taf_asset_total_outgoing_bandwidth_external,taf_asset_total_outgoing_bandwidth_internal,taf_asset_top_dest_countries,taf_asset_top_source_countries,taf_asset_top_dest_countries,taf_asset_top_source_countries'
              },
              'queryParams': {
                'user': 'assetId:pathParam',
                'window': ''
              },
              'id': 'assetReports'
            }
          ],
          'title': 'Risk Profile'
        },
        'name': 'AssetDetails',
        'attributes': {
          'style': {
            'width': '250px',
            'flex': '0 0 250px',
            'backgroundColor': '#F7F7F9'
          }
        }
      },
      {
        'id': 'network-graph',
        'type': 'NetworkGraph',
        'name': 'NetworkGraph',
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/entity/{type}/{assetId}',
            'pathParams': {
              'assetId': ':pathParam',
              'type': ':pathParam'
            },
            'queryParams': {},
            'id': 'assetDetail'
          },
          'title': 'Overview'
        },
        'attributes': {
          'style': {
            'height': '725px',
            'width': '80%'
          },
          'id': 'NetworkGraph'
        }
      }
    ],
    [
      {
        'id': 'asset-activity',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'title': 'Activity',
          'showRefresh': false
        },
        "innerStyle": {
          "flexDirection": "column"
        },
        'attributes': {
          'style': {
            'width': '300px'
          },
          'id': 'activity'
        },
        children: [
          // {
          //   'id': 'dns-lookup',
          //   'type': 'ZoomLineChart',
          //   'meta': {
          //     'showHeader': true,
          //     'api': {
          //       'path': '/api/analytics/reporting/execute/{reportId}',
          //       'pathParams': {
          //         'reportId': 'taf_asset_dns_count_by_time'
          //       },
          //       'queryParams': {
          //         'window': ''
          //       },
          //       'id': 'assetDetail'
          //     },
          //     'title': 'DNS Lookups'
          //   },
          //   'attributes': {
          //     'style': {
          //       'width': '300px'
          //     },
          //     'id': 'dns-lookup-chart'
          //   }
          // },
          {
            "chartOptions": {
              "paletteColors": "#C9EDDF, #60E2DC",
              "xAxisName": "TIME",
              "lineThickness": "1",
              "showYAxisValues": "1",
              "drawAnchors": "0",
              "xAxisNameFontSize": '10',
              "yAxisNameFontSize": '10',
              "labelFontSize": "8",
              "drawAnchors": "1",
              "showlegend": "0"
            },
            "chartData": {
              "combinedResult": false,
              "fieldMapping": [
                {
                  "axis": "x",
                  "reportId": "taf_asset_dns_count_by_time",
                  "columns": [
                    "date"
                  ]
                },
                {
                  "axis": "y",
                  "seriesOptions": {
                    "renderas": "Line"
                  },
                  "reportId": "taf_asset_dns_count_by_time",
                  "columns": [
                    "data.dns.rCodeName",
                    "data.dns.query"
                  ]
                }
              ]
            },
            "meta": {
              "subTitle": "(in bytes)",
              "showHeader": true,
              "showRefresh": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "pathParams": {
                  "reportId": "taf_asset_dns_count_by_time"
                },
                "queryParams": {
                  "window": ""
                }
              },
              "title": "DNS Lookups"
            },
            "attributes": {
              "chartHeight": "250",
              "chartCaption": {
                "display": "none"
              },
              "style": {
                'width': '100%',
                'padding': 0,
                'boxShadow': 'none'
              },
              "id": "dns-lookups-chart"
            },
            "id": "dns-lookups",
            "type": "MultiSeriesCombiChart"
          },
          {
            'id': 'connections-by-protocol',
            'type': 'HorizontalBarChart',
            'meta': {
              'showHeader': true,
              'showRefresh': false,
              'api': {
                'path': '/api/analytics/reporting/execute/{reportId}',
                'pathParams': {
                  'reportId': 'taf_connections_by_protocol'
                },
                'queryParams': {
                  'window': ''
                }
              },
              'title': 'Connections By Protocol'
            },
            'attributes': {
              'chartCaption': {
                'display': 'none'
              },
              'chartWidth': '250px',
              'chartHeight': '250px',
              'style': {
                'width': '100%',
                'padding': 0,
                'boxShadow': 'none'
              },
              'id': 'connections-by-protocol-chart'
            },
            'chartOptions': {
              'showValues': '1',
              'showLabels': '1',
              'chartRightMargin': '0'
            },
            'chart': {
              'showAnnotations': false
            },
            'chartData': {
              'showTrendLines': false,
              'fieldMapping': [
                {
                  'reportId': 'taf_connections_by_protocol',
                  'columns': [
                    'protocol.service',
                    'date'
                  ]
                }
              ],
              'multipleReportIds': false
            }
          }
        ]
      }
    ]
  ]
};

const timeline = {
  'layout': [
    [
      {
        "id": "timeline",
        "type": "Timeline",
        "name": "Timeline",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/alert/{type}",
            "queryParams": {
              "window": "",
              "date": "2016-09-23T05:51:53.019",
              "filter": "(source.ip = 121.18.238.98 AND destination.ip = 172.31.7.62) OR (source.ip = 172.31.7.62 AND destination.ip = 121.18.238.98)",
              "count": 50,
              "from": 0
            },
            "pathParams": {
              "type": "traffic"
            }
          },
          "title": "Timeline"
        },
        "attributes": {
          "type": "traffic",
          "displaySelectedRows": true,
          "noOfEventsPerPage": 50,
          "maxNumbersOnLeftRightPagination": 4,
          "style": {
            "height": "1105px",
            "width": "100%",
            "backgroundColor": "#F7F7F9"
          },
          "id": "Timeline"
        }
      }
    ] // ,*/
    /*[
      {
        "id": "timeline-asset",
        "type": "Timeline",
        "name": "Timeline",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "count": 50,
              "from": 0
            },
            "pathParams": {
              "reportId": "taf_alert_by_asset"
            }
          },
          "title": "Timeline"
        },
        "attributes": {
          "type": "alert",
          "displaySelectedRows": true,
          "noOfEventsPerPage": 50,
          "maxNumbersOnLeftRightPagination": 4,
          "style": {
            "height": "1105px",
            "width": "100%",
            "backgroundColor": "#F7F7F9"
          },
          "id": "Timeline"
        }
      }
    ]*/
  ]
};

const alertPage = {
  'layout': [
    [
      {
        'meta': {
          'showHeader': true,
          'showRefresh': false,
          'api': {
            'path': '/api/alert/{alertId}',
            'pathParams': {
              'alertId': ':pathParam'
            },
            'queryParams': {
              'date': 'date:pathParam',
              'window': ''
            }
          },
          'title': 'Alert Detail',
          'fetchDataFor': [
            {
              'id': 'connection-status,connection-by-type,data-source-dest',
              'api': {
                'method': 'POST',
                'path': '/api/analytics/reporting/executeById',
                'body': 'data.rank_alert.chartsFilter$customParam',
                'pathParams': {},
                'queryParams': {
                  'window': ''
                },
                'loadOnce': true
              }
            },
            {
              'id': 'timeline',
              'api': {
                'method': 'GET',
                'path': '/api/alert/traffic',
                'pathParams': {},
                'queryParams': {
                  'count': 50,
                  'from': 0,
                  'window': '',
                  'filter': 'data.rank_alert.trafficFilter$customParam',
                  'date': ':pathParam'
                }
              }
            }
          ]
        },
        'name': 'AlertDetail',
        'attributes': {
          'style': {
            'backgroundColor': '#F7F7F9',
            'width': '250px',
            'flex': '0 0 250px'
          }
        },
        'id': 'alert-detail',
        'type': 'AlertDetailsNew'
      },
      {
        'meta': {
          'showHeader': true,
          'api': {
            'path': '/api/analytics/graph/{alertId}',
            'pathParams': {
              'alertId': ':pathParam'
            },
            'queryParams': {}
          },
          'title': 'Overview'
        },
        'name': 'NetworkGraph',
        'attributes': {
          'style': {
            'width': '100%'
          },
          'id': 'NetworkGraph'
        },
        'id': 'network-graph',
        'type': 'NetworkGraph'
      }
    ],
    [
      /*{
        'id': 'alert-activity',
        'type': 'Compound',
        'name': 'Compound',
        'meta': {
          'showHeader': true,
          'title': 'Activity',
          'showRefresh': false
        },
        'innerStyle': {
          'flexDirection': 'column'
        },
        'attributes': {
          'style': {
            'width': '300px',
            'flexDirection': 'column'
          },
          'id': 'activity'
        },
        'children': [
          {
            'chartOptions': {
              'xAxisName': 'TIME',
              'divLineThickness': '2',
              'lineThickness': '1',
              'showYAxisValues': '1',
              'xAxisNameFontSize': '10',
              'yAxisNameFontSize': '10',
              'labelFontSize': '8',
              'drawAnchors': '1',
              'anchorRadius': '1',
              'showlegend': '0',
              'outCnvBaseFontSize': '8'
            },
            'chartData': {
              'multipleReports': true,
              'fieldMapping': {
                'x': [{
                  'reportId': 'taf_conn_by_status',
                  'columns': ['date']
                }],
                'y': [
                  {
                    'reportId': 'taf_conn_by_status',
                    'columns': [
                      'count'
                    ],
                    'seriesname': 'Connection Status'
                  }
                ]
              }
            },
            'meta': {
              'showHeader': true,
              'showRefresh': false,
              'api': null,
              'title': 'Connection by Status'
            },
            'attributes': {
              'chartHeight': '200',
              'chartCaption': {
                'display': 'none'
              },
              'style': {
                'width': '100%',
                'padding': 0,
                'boxShadow': 'none',
                'marginBottom': '35px'
              },
              'header': {
                'style': {
                  'paddingBottom': 0
                },
                'title': {
                  'fontSize': '13px',
                  'fontWeight': 600,
                  'textTransform': 'capitalize'
                }
              },
              'id': 'connection-status-chart'
            },
            'id': 'connection-status',
            'type': 'MultiSeriesLineChart'
          },
          {
            'chartOptions': {
              'xAxisName': 'TIME',
              'divLineThickness': '2',
              'lineThickness': '1',
              'showYAxisValues': '1',
              'xAxisNameFontSize': '10',
              'yAxisNameFontSize': '10',
              'labelFontSize': '8',
              'drawAnchors': '1',
              'anchorRadius': '1',
              'showlegend': '0',
              'outCnvBaseFontSize': '8'
            },
            'chartData': {
              'fieldMapping': {
                'x': [{
                  'reportId': 'taf_conn_by_type',
                  'columns': ['date']
                }],
                'y': [{
                  'reportId': 'taf_conn_by_type',
                  'columns': ['count']
                }]
              },
              'filter': {
                'reportId': 'taf_conn_by_type',
                'columns': ['type']
              }
            },
            'meta': {
              'showHeader': true,
              'showRefresh': false,
              'api': null,
              'title': 'Connections by type'
            },
            'attributes': {
              'chartHeight': '200',
              'chartCaption': {
                'display': 'none'
              },
              'style': {
                'width': '100%',
                'padding': 0,
                'boxShadow': 'none',
                'marginBottom': '35px'
              },
              'header': {
                'style': {
                  'paddingBottom': 0
                },
                'title': {
                  'fontSize': '13px',
                  'fontWeight': 600,
                  'textTransform': 'capitalize'
                }
              },
              'id': 'connection-by-type-chart'
            },
            'id': 'connection-by-type',
            'type': 'MultiSeriesLineChart'
          },
          {
            'chartOptions': {
              'xAxisName': 'TIME',
              'divLineThickness': '2',
              'lineThickness': '1',
              'showYAxisValues': '1',
              'xAxisNameFontSize': '10',
              'yAxisNameFontSize': '10',
              'labelFontSize': '8',
              'drawAnchors': '1',
              'anchorRadius': '1',
              'showlegend': '0',
              'outCnvBaseFontSize': '8'
            },
            'chartData': {
              'multipleReports': true,
              'fieldMapping': {
                'x': [{
                  'reportId': 'taf_data_between_source_and_destination',
                  'columns': ['date']
                }],
                'y': [
                  {
                    'reportId': 'taf_data_between_source_and_destination',
                    'columns': [
                      'count'
                    ],
                    'seriesname': 'Connection Status'
                  }
                ]
              }
            },
            'meta': {
              'showHeader': true,
              'showRefresh': false,
              'api': null,
              'title': 'Data b/w source and destination'
            },
            'attributes': {
              'chartHeight': '200',
              'chartCaption': {
                'display': 'none'
              },
              'style': {
                'width': '100%',
                'padding': 0,
                'boxShadow': 'none'
              },
              'header': {
                'style': {
                  'paddingBottom': 0
                },
                'title': {
                  'fontSize': '13px',
                  'fontWeight': 600,
                  'textTransform': 'capitalize'
                }
              },
              'id': 'data-source-dest-chart'
            },
            'id': 'data-source-dest',
            'type': 'MultiSeriesLineChart'
          }
        ]
      },*/
      {
        'id': 'timeline',
        'type': 'Timeline',
        'meta': {
          'showHeader': true,
          'api': null,
          'title': 'Timeline'
        },
        'attributes': {
          'type': 'traffic',
          'displaySelectedRows': true,
          'noOfEventsPerPage': 50,
          'maxNumbersOnLeftRightPagination': 4,
          'topMarginLag': 980,
          'style': {
            'height': '1105px',
            'width': '100%',
            'backgroundColor': '#F7F7F9'
          },
          'id': 'timeline-component'
        }
      }
    ]
  ]
};

const assetPage = {
  "layout": [
    [
      {
        "id": "asset-detail",
        "type": "AssetDetails",
        "meta": {
          "showHeader": true,
          "api": [
            {
              "path": "/api/entity/{type}/{assetId}",
              "pathParams": {
                "assetId": ":pathParam",
                "type": ":pathParam"
              },
              "queryParams": {},
              "id": "assetDetail"
            },
            {
              "path": "/api/analytics/reporting/execute/{reportId}",
              "pathParams": {
                "reportId": "taf_asset_session_count,taf_asset_internal_resource_count,taf_asset_total_incoming_bandwidth_external,taf_asset_total_incoming_bandwidth_internal,taf_asset_total_outgoing_bandwidth_external,taf_asset_total_outgoing_bandwidth_internal,taf_asset_top_dest_countries,taf_asset_top_source_countries,taf_asset_top_dest_countries,taf_asset_top_source_countries"
              },
              "queryParams": {
                "user": "assetId:pathParam",
                "window": ""
              },
              "id": "assetReports"
            }
          ],
          "title": "Risk Profile"
        },
        "name": "AssetDetails",
        "attributes": {
          "style": {
            "width": "250px",
            "flex": "0 0 250px",
            "backgroundColor": "#F7F7F9"
          }
        }
      },
      {
        "id": "network-graph",
        "type": "NetworkGraph",
        "name": "NetworkGraph",
        "meta": {
          "showHeader": true,
          "api": {
            "path": "/api/entity/{type}/{assetId}",
            "pathParams": {
              "assetId": ":pathParam",
              "type": ":pathParam"
            },
            "queryParams": {},
            "id": "assetDetail"
          },
          "title": "Overview"
        },
        "attributes": {
          "style": {
            "width": "80%"
          },
          "id": "NetworkGraph"
        }
      }
    ],
    [
      {
        "id": "asset-activity",
        "type": "Compound",
        "name": "Compound",
        "meta": {
          "showHeader": true,
          "title": "Activity",
          "showRefresh": false
        },
        "innerStyle": {
          "flexDirection": "column"
        },
        "attributes": {
          "style": {
            "width": "300px",
            "flexDirection": "column"
          },
          "id": "activity"
        },
        "children": [
          {
            "chartOptions": {
              "xAxisName": "TIME",
              "divLineThickness": "2",
              "lineThickness": "1",
              "showYAxisValues": "1",
              "xAxisNameFontSize": "10",
              "yAxisNameFontSize": "10",
              "labelFontSize": "8",
              "drawAnchors": "1",
              "anchorRadius": "1",
              "showlegend": "0",
              "outCnvBaseFontSize": "8"
            },
            "chartData": {
              "fieldMapping": {
                "x": [{
                  "reportId": "taf_asset_dns_count_by_time",
                  "columns": ["date"]
                }],
                "y": [{
                  "reportId": "taf_asset_dns_count_by_time",
                  "columns": [
                    "data.dns.query"
                  ]
                }]
              },
              "filter": {
                "reportId": "taf_asset_dns_count_by_time",
                "columns": [
                  "data.dns.rCodeName"
                ]
              }
            },
            "meta": {
              "showHeader": true,
              "showRefresh": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "pathParams": {
                  "reportId": "taf_asset_dns_count_by_time"
                },
                "queryParams": {
                  "window": ""
                }
              },
              "title": "DNS Lookups"
            },
            "attributes": {
              "chartHeight": "200",
              "chartCaption": {
                "display": "none"
              },
              "style": {
                "width": "100%",
                "padding": 0,
                "boxShadow": "none",
                "marginBottom": "35px"
              },
              "header": {
                "style": {
                  "paddingBottom": 0
                },
                "title": {
                  "fontSize": "13px",
                  "fontWeight": 600,
                  "textTransform": "capitalize"
                }
              },
              "id": "dns-lookups-chart"
            },
            "id": "dns-lookups",
            "type": "MultiSeriesLineChart"
          },
          {
            "chartOptions": {
              "paletteColors": "#2bd8d0,#F69275",
              "xAxisName": "MACHINES IN NETWORK",
              "divLineThickness": "2",
              "showYAxisValues": "1",
              "xAxisNameFontSize": "10",
              "yAxisNameFontSize": "10",
              "labelFontSize": "8",
              "drawAnchors": "1",
              "anchorRadius": "1",
              "showlegend": "0",
              "outCnvBaseFontSize": "8"
            },
            "chartData": {},
            "meta": {
              "showHeader": true,
              "showRefresh": false,
              "api": null,
              "title": "Login Count"
            },
            "attributes": {
              "chartHeight": "200",
              "chartCaption": {
                "display": "none"
              },
              "style": {
                "width": "100%",
                "padding": 0,
                "boxShadow": "none",
                "marginBottom": "35px"
              },
              "header": {
                "style": {
                  "paddingBottom": 0
                },
                "title": {
                  "fontSize": "13px",
                  "fontWeight": 600,
                  "textTransform": "capitalize"
                }
              },
              "id": "login-count-chart"
            },
            "id": "login-count",
            "type": "MultiSeriesColumn2d"
          },
          {
            "header": {
              "style": {
                "paddingBottom": 0
              },
              "title": {
                "fontSize": "13px",
                "fontWeight": 600,
                "textTransform": "capitalize"
              }
            },
            "id": "connections-by-protocol",
            "type": "HorizontalBarChart",
            "meta": {
              "showHeader": true,
              "showRefresh": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "pathParams": {
                  "reportId": "taf_connections_by_protocol"
                },
                "queryParams": {
                  "window": ""
                }
              },
              "title": "Connections By Protocol"
            },
            "attributes": {
              "chartCaption": {
                "display": "none"
              },
              "chartWidth": "100%",
              "chartHeight": "200px",
              "style": {
                "width": "100%",
                "padding": 0,
                "boxShadow": "none"
              },
              "header": {
                "style": {
                  "paddingBottom": 0
                },
                "title": {
                  "fontSize": "13px",
                  "fontWeight": 600,
                  "textTransform": "capitalize"
                }
              },
              "id": "connections-by-protocol-chart"
            },
            "chartOptions": {
              "showValues": "1",
              "showLabels": "1",
              "chartRightMargin": "0",
              "divLineThickness": "2"
            },
            "chart": {
              "showAnnotations": false
            },
            "chartData": {
              "showTrendLines": false,
              "fieldMapping": [
                {
                  "reportId": "taf_connections_by_protocol",
                  "columns": [
                    "protocol.service",
                    "date"
                  ]
                }
              ],
              "multipleReportIds": false
            }
          },
          {
            "chartOptions": {
              "xAxisName": "TIME",
              "divLineThickness": "2",
              "lineThickness": "1",
              "showYAxisValues": "1",
              "xAxisNameFontSize": "10",
              "yAxisNameFontSize": "10",
              "labelFontSize": "8",
              "drawAnchors": "1",
              "anchorRadius": "1",
              "showlegend": "0",
              "outCnvBaseFontSize": "8"
            },
            "chartData": {
              "multipleReports": true,
              "fieldMapping": {
                "x": [{
                  "reportId": "taf_asset_total_bandwidth_internal_by_time",
                  "columns": ["date"]
                }],
                "y": [
                  {
                    "reportId": "taf_asset_total_bandwidth_internal_by_time",
                    "columns": [
                      "bandwidth"
                    ],
                    "seriesname": "Internal Bandwidth"
                  },
                  {
                    "reportId": "taf_asset_total_bandwidth_external_by_time",
                    "columns": [
                      "bandwidth"
                    ],
                    "seriesname": "External Bandwidth"
                  }
                ]
              }
            },
            "meta": {
              "showHeader": true,
              "showRefresh": false,
              "api": {
                "path": "/api/analytics/reporting/execute/{reportId}",
                "pathParams": {
                  "reportId": "taf_asset_total_bandwidth_internal_by_time,taf_asset_total_bandwidth_external_by_time"
                },
                "queryParams": {
                  "window": ""
                }
              },
              "title": "Data Transfered"
            },
            "attributes": {
              "chartHeight": "200",
              "chartCaption": {
                "display": "none"
              },
              "style": {
                "width": "100%",
                "padding": 0,
                "boxShadow": "none",
                "marginTop": "35px"
              },
              "header": {
                "style": {
                  "paddingBottom": 0
                },
                "title": {
                  "fontSize": "13px",
                  "fontWeight": 600,
                  "textTransform": "capitalize"
                }
              },
              "id": "data-transfer-chart"
            },
            "id": "data-transfer",
            "type": "MultiSeriesLineChart"
          }
        ]
      },
      {
        'id': 'timeline',
        'type': 'Timeline',
        'meta': {
          'showHeader': true,
          "api": {
            "path": "/api/analytics/reporting/execute/{reportId}",
            "queryParams": {
              "window": "",
              "count": 50,
              "from": 0
            },
            "pathParams": {
              "reportId": "taf_alert_by_asset"
            }
          },
          'title': 'Timeline'
        },
        'attributes': {
          'type': 'traffic',
          'displaySelectedRows': true,
          'noOfEventsPerPage': 50,
          'maxNumbersOnLeftRightPagination': 4,
          'topMarginLag': 1030,
          'style': {
            'height': 'auto',
            'width': '100%',
            'backgroundColor': '#F7F7F9'
          },
          'id': 'timeline-component'
        }
      }
    ]
  ]
};

export default alertPage;
// export default assetPage;

// export default alertDetails;
// export default timeline;
